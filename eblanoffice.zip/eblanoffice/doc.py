#!/usr/bin/env python3
import sys
import zipfile
import json
import os
import tempfile
import mimetypes
import shutil
import argparse
from pathlib import Path
from datetime import datetime
from settings_manager import SettingsManager

from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *
from PySide6.QtPrintSupport import *

# ==============================
# КОНФИГУРАЦИЯ ПРОГРАММЫ
# ==============================
class AppConfig:
    # Название программы
    APP_NAME = "EblanOffice Глагол"

    # Расширение документов по умолчанию
    FILE_EXTENSION = ".ebldoc"
    FILE_FILTER = "Документы EblanOffice Глагол (*.ebldoc)"

    # Иконка программы
    APP_ICON = "icons/doc.png"  # Используем иконку из папки icons

    # Название файла по умолчанию
    DEFAULT_FILENAME = "Безымянный"

    # Префикс для временной папки
    TEMP_PREFIX = "eblanglagol_"

    # Версия формата
    FORMAT_VERSION = "1.0"

    # Файл для истории документов
    RECENT_DOCS_FILE = ".recentdocuments.json"
    MAX_RECENT_DOCS = 20
# ==============================


# ==============================
# КЛАСС ДЛЯ РАБОТЫ С ИСТОРИЕЙ ДОКУМЕНТОВ
# ==============================
class RecentDocuments:
    def __init__(self, filename=AppConfig.RECENT_DOCS_FILE):
        self.filename = filename
        self.documents = []
        self.load()

    def load(self):
        """Загрузить историю документов из файла"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.documents = data.get("recent_documents", [])
            except:
                self.documents = []
        else:
            self.documents = []

    def save(self):
        """Сохранить историю документов в файл"""
        data = {"recent_documents": self.documents}
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except:
            return False

    def add_document(self, file_path):
        """Добавить документ в историю"""
        # Проверяем, существует ли файл
        if not os.path.exists(file_path):
            return False

        # Создаем запись о документе
        doc_info = {
            "path": file_path,
            "name": os.path.basename(file_path),
            "type": "document",  # Тип документа
            "last_opened": datetime.now().isoformat()
        }

        # Удаляем старую запись, если она существует
        self.documents = [doc for doc in self.documents if doc["path"] != file_path]

        # Добавляем новую запись в начало
        self.documents.insert(0, doc_info)

        # Ограничиваем количество записей
        if len(self.documents) > AppConfig.MAX_RECENT_DOCS:
            self.documents = self.documents[:AppConfig.MAX_RECENT_DOCS]

        # Сохраняем изменения
        return self.save()


# ==============================
# ДИАЛОГОВОЕ ОКНО ДЛЯ НАСТРОЙКИ РАЗМЕРОВ ИЗОБРАЖЕНИЯ
# ==============================
class ImageSizeDialog(QDialog):
    def __init__(self, parent=None, default_width=None, default_height=None):
        super().__init__(parent)
        self.setWindowTitle("Настройка размера изображения")
        self.setModal(True)

        # Основной layout
        layout = QVBoxLayout()

        # Сетка для полей ввода
        form_layout = QGridLayout()

        # Поле для ширины
        self.width_label = QLabel("Ширина (пикселей):")
        self.width_input = QSpinBox()
        self.width_input.setRange(1, 10000)  # Минимальный и максимальный размер
        self.width_input.setValue(default_width if default_width else 400)

        # Поле для высоты
        self.height_label = QLabel("Высота (пикселей):")
        self.height_input = QSpinBox()
        self.height_input.setRange(1, 10000)  # Минимальный и максимальный размер
        self.height_input.setValue(default_height if default_height else 300)

        # Чекбокс для сохранения пропорций
        self.keep_aspect_checkbox = QCheckBox("Сохранять пропорции")
        self.keep_aspect_checkbox.setChecked(True)
        self.original_aspect_ratio = None

        if default_width and default_height:
            self.original_aspect_ratio = default_width / default_height

        # Добавляем виджеты в форму
        form_layout.addWidget(self.width_label, 0, 0)
        form_layout.addWidget(self.width_input, 0, 1)
        form_layout.addWidget(self.height_label, 1, 0)
        form_layout.addWidget(self.height_input, 1, 1)
        form_layout.addWidget(self.keep_aspect_checkbox, 2, 0, 1, 2)

        layout.addLayout(form_layout)

        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.setLayout(layout)

        # Подключаем сигналы для сохранения пропорций
        self.width_input.valueChanged.connect(self.on_width_changed)
        self.height_input.valueChanged.connect(self.on_height_changed)
        self.keep_aspect_checkbox.stateChanged.connect(self.on_aspect_changed)

    def on_width_changed(self, value):
        if self.keep_aspect_checkbox.isChecked() and self.original_aspect_ratio:
            # Сохраняем пропорции при изменении ширины
            new_height = int(value / self.original_aspect_ratio)
            self.height_input.blockSignals(True)  # Блокируем сигналы, чтобы избежать рекурсии
            self.height_input.setValue(new_height)
            self.height_input.blockSignals(False)

    def on_height_changed(self, value):
        if self.keep_aspect_checkbox.isChecked() and self.original_aspect_ratio:
            # Сохраняем пропорции при изменении высоты
            new_width = int(value * self.original_aspect_ratio)
            self.width_input.blockSignals(True)  # Блокируем сигналы, чтобы избежать рекурсии
            self.width_input.setValue(new_width)
            self.width_input.blockSignals(False)

    def on_aspect_changed(self, state):
        # Если включаем сохранение пропорций, запоминаем текущее соотношение
        if state == Qt.Checked and not self.original_aspect_ratio:
            width = self.width_input.value()
            height = self.height_input.value()
            if height > 0:
                self.original_aspect_ratio = width / height

    def get_size(self):
        return self.width_input.value(), self.height_input.value()
# ==============================


class DocumentEditor(QMainWindow):
    def __init__(self, file_to_open=None):
        super().__init__()
        self.current_file = file_to_open
        self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)
        self.images = {}  # Хранит соответствие image_id -> путь к файлу
        self.next_image_id = 1
        self.recent_docs = RecentDocuments()
        self.init_ui()

        # Если передан файл для открытия, загружаем его
        if file_to_open and os.path.exists(file_to_open):
            QTimer.singleShot(100, lambda: self.load_from_file(file_to_open))

    def init_ui(self):
        self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION} - {AppConfig.APP_NAME}")
        self.setGeometry(100, 100, 1200, 800)

        # Устанавливаем иконку
        if os.path.exists(AppConfig.APP_ICON):
            self.setWindowIcon(QIcon(AppConfig.APP_ICON))
        else:
            # Запасной вариант - иконка из темы
            self.setWindowIcon(QIcon.fromTheme("accessories-text-editor"))

        # Создание центрального виджета
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Панель инструментов
        toolbar = QToolBar()
        self.addToolBar(toolbar)

        # Кнопки файлов
        new_action = QAction(QIcon.fromTheme("document-new"), "Новый", self)
        new_action.triggered.connect(self.new_document)
        toolbar.addAction(new_action)

        open_action = QAction(QIcon.fromTheme("document-open"), "Открыть", self)
        open_action.triggered.connect(self.open_document)
        toolbar.addAction(open_action)

        save_action = QAction(QIcon.fromTheme("document-save"), "Сохранить", self)
        save_action.triggered.connect(self.save_document)
        toolbar.addAction(save_action)

        save_as_action = QAction(QIcon.fromTheme("document-save-as"), "Сохранить как", self)
        save_as_action.triggered.connect(self.save_document_as)
        toolbar.addAction(save_as_action)

        toolbar.addSeparator()

        # Кнопки форматирования
        toolbar.addWidget(QLabel("Шрифт:"))
        self.font_combo = QFontComboBox()
        self.font_combo.currentFontChanged.connect(self.set_font)
        toolbar.addWidget(self.font_combo)

        toolbar.addWidget(QLabel("Размер:"))
        self.size_combo = QComboBox()
        self.size_combo.setEditable(True)  # Делаем редактируемым для ввода произвольного размера
        self.size_combo.addItems(["8", "9", "10", "11", "12", "14", "16", "18", "20", "22", "24", "28", "32", "36", "48", "72"])
        self.size_combo.currentTextChanged.connect(self.set_font_size)
        toolbar.addWidget(self.size_combo)

        color_action = QAction(QIcon.fromTheme("format-text-color"), "Цвет текста", self)
        color_action.triggered.connect(self.set_text_color)
        toolbar.addAction(color_action)

        toolbar.addSeparator()

        self.bold_action = QAction(QIcon.fromTheme("format-text-bold"), "Жирный", self)
        self.bold_action.triggered.connect(self.set_bold)
        self.bold_action.setCheckable(True)
        toolbar.addAction(self.bold_action)

        self.italic_action = QAction(QIcon.fromTheme("format-text-italic"), "Курсив", self)
        self.italic_action.triggered.connect(self.set_italic)
        self.italic_action.setCheckable(True)
        toolbar.addAction(self.italic_action)

        self.underline_action = QAction(QIcon.fromTheme("format-text-underline"), "Подчеркнутый", self)
        self.underline_action.triggered.connect(self.set_underline)
        self.underline_action.setCheckable(True)
        toolbar.addAction(self.underline_action)

        self.strike_action = QAction(QIcon.fromTheme("format-text-strikethrough"), "Перечеркнутый", self)
        self.strike_action.triggered.connect(self.set_strike)
        self.strike_action.setCheckable(True)
        toolbar.addAction(self.strike_action)

        toolbar.addSeparator()

        self.align_left_action = QAction(QIcon.fromTheme("format-justify-left"), "Выровнять по левому краю", self)
        self.align_left_action.triggered.connect(lambda: self.set_alignment(Qt.AlignLeft))
        self.align_left_action.setCheckable(True)
        self.align_left_action.setChecked(True)
        toolbar.addAction(self.align_left_action)

        self.align_center_action = QAction(QIcon.fromTheme("format-justify-center"), "Выровнять по центру", self)
        self.align_center_action.triggered.connect(lambda: self.set_alignment(Qt.AlignCenter))
        self.align_center_action.setCheckable(True)
        toolbar.addAction(self.align_center_action)

        self.align_right_action = QAction(QIcon.fromTheme("format-justify-right"), "Выровнять по правому краю", self)
        self.align_right_action.triggered.connect(lambda: self.set_alignment(Qt.AlignRight))
        self.align_right_action.setCheckable(True)
        toolbar.addAction(self.align_right_action)

        # Группа для выравнивания
        self.alignment_group = QActionGroup(self)
        self.alignment_group.addAction(self.align_left_action)
        self.alignment_group.addAction(self.align_center_action)
        self.alignment_group.addAction(self.align_right_action)

        toolbar.addSeparator()

        # Кнопка вставки изображения
        image_action = QAction(QIcon.fromTheme("insert-image"), "Вставить изображение", self)
        image_action.triggered.connect(self.insert_image)
        toolbar.addAction(image_action)

        # Текстовый редактор
        self.text_edit = QTextEdit()
        self.text_edit.textChanged.connect(self.update_window_title)
        self.text_edit.cursorPositionChanged.connect(self.update_format_buttons)
        layout.addWidget(self.text_edit)

        # Применяем начальное форматирование
        self.update_format_buttons()

    def update_format_buttons(self):
        try:
            cursor = self.text_edit.textCursor()
            if not cursor:
                return

            char_format = cursor.charFormat()

            # Обновляем состояние кнопок форматирования
            self.bold_action.setChecked(char_format.fontWeight() == QFont.Bold)
            self.italic_action.setChecked(char_format.fontItalic())
            self.underline_action.setChecked(char_format.fontUnderline())
            self.strike_action.setChecked(char_format.fontStrikeOut())

            # Обновляем выравнивание
            alignment = self.text_edit.alignment()
            self.align_left_action.setChecked(alignment == Qt.AlignLeft)
            self.align_center_action.setChecked(alignment == Qt.AlignCenter)
            self.align_right_action.setChecked(alignment == Qt.AlignRight)

            # Обновляем комбобоксы шрифта и размера
            # Временно отключаем сигналы, чтобы не вызывать set_font/set_font_size
            self.font_combo.blockSignals(True)
            self.size_combo.blockSignals(True)

            # Получаем текущий шрифт - используем новый метод fontFamilies()
            font_families = char_format.fontFamilies()
            if font_families:
                # В PySide6 fontFamilies() возвращает список строк
                # Берем первое семейство шрифтов
                if isinstance(font_families, list) and len(font_families) > 0:
                    current_font_family = font_families[0]
                elif hasattr(font_families, 'toString'):
                    # Для обратной совместимости
                    current_font_family = font_families.toString().split(',')[0] if font_families.toString() else ""
                else:
                    current_font_family = str(font_families)

                if current_font_family:
                    # Находим индекс шрифта в QFontComboBox
                    index = self.font_combo.findText(current_font_family)
                    if index >= 0:
                        self.font_combo.setCurrentIndex(index)
                    else:
                        # Если шрифт не найден в списке, устанавливаем его
                        self.font_combo.setCurrentFont(QFont(current_font_family))

            # Получаем текущий размер шрифта
            current_font_size = char_format.fontPointSize()
            if current_font_size > 0:
                # Ищем размер в списке
                size_text = str(int(current_font_size))
                index = self.size_combo.findText(size_text)
                if index >= 0:
                    self.size_combo.setCurrentIndex(index)
                else:
                    # Если размера нет в списке, добавляем его
                    self.size_combo.setCurrentText(size_text)

            # Включаем сигналы обратно
            self.font_combo.blockSignals(False)
            self.size_combo.blockSignals(False)
        except Exception as e:
            print(f"Error in update_format_buttons: {e}")
            # Включаем сигналы в случае ошибки
            self.font_combo.blockSignals(False)
            self.size_combo.blockSignals(False)

    def update_window_title(self):
        modified = "*" if self.text_edit.document().isModified() else ""
        if self.current_file:
            file_name = Path(self.current_file).name
            self.setWindowTitle(f"{file_name}{modified} - {AppConfig.APP_NAME}")
        else:
            self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION}{modified} - {AppConfig.APP_NAME}")

    def set_font(self, font):
        cursor = self.text_edit.textCursor()
        if cursor.hasSelection():
            fmt = cursor.charFormat()
            # Используем новый метод setFontFamilies вместо устаревшего setFontFamily
            fmt.setFontFamilies([font.family()])
            cursor.mergeCharFormat(fmt)
        else:
            # Для установки шрифта без выделения используем QFont
            current_font = self.text_edit.currentFont()
            current_font.setFamily(font.family())
            self.text_edit.setCurrentFont(current_font)

    def set_font_size(self, size):
        if not size:
            return

        try:
            # Пытаемся преобразовать размер в число
            font_size = float(size)
            cursor = self.text_edit.textCursor()
            if cursor.hasSelection():
                fmt = cursor.charFormat()
                fmt.setFontPointSize(font_size)
                cursor.mergeCharFormat(fmt)
            else:
                # Для установки размера без выделения
                current_font = self.text_edit.currentFont()
                current_font.setPointSizeF(font_size)
                self.text_edit.setCurrentFont(current_font)
        except ValueError:
            # Если введен некорректный размер, игнорируем
            pass

    def set_text_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            cursor = self.text_edit.textCursor()
            if cursor.hasSelection():
                fmt = cursor.charFormat()
                fmt.setForeground(color)
                cursor.mergeCharFormat(fmt)
            else:
                self.text_edit.setTextColor(color)

    def set_bold(self):
        cursor = self.text_edit.textCursor()
        fmt = cursor.charFormat()
        weight = QFont.Normal if fmt.fontWeight() == QFont.Bold else QFont.Bold
        fmt.setFontWeight(weight)
        cursor.mergeCharFormat(fmt)

    def set_italic(self):
        cursor = self.text_edit.textCursor()
        fmt = cursor.charFormat()
        fmt.setFontItalic(not fmt.fontItalic())
        cursor.mergeCharFormat(fmt)

    def set_underline(self):
        cursor = self.text_edit.textCursor()
        fmt = cursor.charFormat()
        fmt.setFontUnderline(not fmt.fontUnderline())
        cursor.mergeCharFormat(fmt)

    def set_strike(self):
        cursor = self.text_edit.textCursor()
        fmt = cursor.charFormat()
        fmt.setFontStrikeOut(not fmt.fontStrikeOut())
        cursor.mergeCharFormat(fmt)

    def set_alignment(self, alignment):
        self.text_edit.setAlignment(alignment)
        self.update_format_buttons()

    def insert_image(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Выберите изображение", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.svg *.webp);;Все файлы (*)"
        )

        if file_name:
            try:
                # Загружаем изображение для получения оригинальных размеров
                image = QImage(file_name)
                if image.isNull():
                    QMessageBox.warning(self, "Ошибка", "Не удалось загрузить изображение")
                    return

                # Получаем оригинальные размеры
                original_width = image.width()
                original_height = image.height()

                # Создаем диалоговое окно для настройки размеров
                dialog = ImageSizeDialog(self, original_width, original_height)

                if dialog.exec() == QDialog.Accepted:
                    # Получаем выбранные размеры
                    width, height = dialog.get_size()

                    # Определяем расширение файла
                    ext = os.path.splitext(file_name)[1].lower()
                    if not ext:
                        ext = ".png"  # По умолчанию, если нет расширения

                    # Создаем уникальный ID и путь для изображения
                    image_id = f"image_{self.next_image_id}{ext}"
                    self.next_image_id += 1

                    # Копируем изображение во временную папку
                    temp_image_path = os.path.join(self.temp_dir, image_id)
                    shutil.copy2(file_name, temp_image_path)

                    # Сохраняем информацию об изображении
                    self.images[image_id] = temp_image_path

                    # Вставляем изображение в документ с заданными размерами
                    cursor = self.text_edit.textCursor()
                    image_format = QTextImageFormat()
                    image_format.setName(temp_image_path)  # Указываем полный путь к файлу

                    # Устанавливаем размеры изображения
                    image_format.setWidth(width)
                    image_format.setHeight(height)

                    cursor.insertImage(image_format)

            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось вставить изображение: {str(e)}")

    def new_document(self):
        if self.maybe_save():
            self.text_edit.clear()
            self.current_file = None
            self.images.clear()
            self.next_image_id = 1
            self.update_window_title()

            # Очищаем временную папку
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
            self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)

    def open_document(self):
        if self.maybe_save():
            file_name, _ = QFileDialog.getOpenFileName(
                self, "Открыть документ", "",
                f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
            )

            if file_name:
                self.load_from_file(file_name)

    def save_document(self):
        if self.current_file:
            self.save_to_file(self.current_file)
        else:
            self.save_document_as()

    def save_document_as(self):
        file_name, _ = QFileDialog.getSaveFileName(
            self, "Сохранить документ", "",
            f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
        )

        if file_name:
            if not file_name.endswith(AppConfig.FILE_EXTENSION):
                file_name += AppConfig.FILE_EXTENSION
            self.save_to_file(file_name)

    def maybe_save(self):
        if self.text_edit.document().isModified():
            reply = QMessageBox.question(
                self, "Сохранение",
                "Документ был изменен. Сохранить изменения?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )

            if reply == QMessageBox.Save:
                self.save_document()
                return True
            elif reply == QMessageBox.Cancel:
                return False

        return True

    def extract_images_from_html(self, html_content):
        """Извлекает ссылки на изображения из HTML"""
        image_paths = []
        import re

        # Ищем все теги img с атрибутом src
        img_pattern = r'<img[^>]+src="([^"]+)"[^>]*>'
        for match in re.finditer(img_pattern, html_content):
            src = match.group(1)
            if src.startswith('file://'):
                src = src[7:]  # Убираем file://
            image_paths.append(src)

        return image_paths

    def save_to_file(self, file_path):
        try:
            # Создаем временный zip-файл
            temp_zip_path = file_path + ".temp"

            with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Получаем HTML контент
                html_content = self.text_edit.toHtml()

                # Извлекаем изображения из HTML
                image_paths = self.extract_images_from_html(html_content)

                # Сохраняем изображения
                image_info = {}
                for i, image_path in enumerate(image_paths):
                    if os.path.exists(image_path):
                        # Определяем расширение файла
                        ext = os.path.splitext(image_path)[1].lower()
                        if not ext:
                            # Пытаемся определить MIME-тип
                            mime_type, _ = mimetypes.guess_type(image_path)
                            if mime_type:
                                ext = mimetypes.guess_extension(mime_type) or ".bin"

                        image_id = f"image_{i}{ext}"
                        image_info[image_path] = image_id

                        # Заменяем путь в HTML на относительный
                        html_content = html_content.replace(
                            f'src="{image_path}"',
                            f'src="images/{image_id}"'
                        )
                        html_content = html_content.replace(
                            f'src="file://{image_path}"',
                            f'src="images/{image_id}"'
                        )

                        # Сохраняем изображение в архив
                        with open(image_path, 'rb') as f:
                            image_data = f.read()
                        zipf.writestr(f"images/{image_id}", image_data)

                # Метаданные
                metadata = {
                    "created": datetime.now().isoformat(),
                    "modified": datetime.now().isoformat(),
                    "image_count": len(image_paths),
                    "format": AppConfig.FORMAT_VERSION,
                    "images": image_info
                }

                # Сохраняем документ и метаданные
                zipf.writestr("document.html", html_content)
                zipf.writestr("metadata.json", json.dumps(metadata, indent=2, ensure_ascii=False))

            # Заменяем старый файл новым
            if os.path.exists(file_path):
                os.remove(file_path)
            os.rename(temp_zip_path, file_path)

            self.current_file = file_path
            self.text_edit.document().setModified(False)
            self.update_window_title()

            # Добавляем документ в историю
            self.recent_docs.add_document(file_path)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить файл: {str(e)}")
            if os.path.exists(temp_zip_path):
                os.remove(temp_zip_path)

    def load_from_file(self, file_path):
        try:
            # Очищаем текущий документ
            self.text_edit.clear()
            self.images.clear()
            self.next_image_id = 1

            # Очищаем временную папку
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
            self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)

            with zipfile.ZipFile(file_path, 'r') as zipf:
                # Загружаем метаданные
                metadata_str = zipf.read("metadata.json").decode('utf-8')
                metadata = json.loads(metadata_str)

                # Загружаем документ
                html_content = zipf.read("document.html").decode('utf-8')

                # Загружаем изображения во временную директорию
                images_dir = "images/"
                for file_info in zipf.infolist():
                    if file_info.filename.startswith(images_dir):
                        image_id = file_info.filename[len(images_dir):]
                        image_data = zipf.read(file_info.filename)

                        # Сохраняем во временный файл
                        temp_image_path = os.path.join(self.temp_dir, image_id)
                        with open(temp_image_path, 'wb') as f:
                            f.write(image_data)

                        self.images[image_id] = temp_image_path

                        # Обновляем next_image_id
                        if image_id.startswith("image_"):
                            try:
                                num = int(image_id[6:].split('.')[0])
                                if num >= self.next_image_id:
                                    self.next_image_id = num + 1
                            except:
                                pass

                # Заменяем относительные пути на абсолютные в HTML
                for image_id, image_path in self.images.items():
                    html_content = html_content.replace(
                        f'src="images/{image_id}"',
                        f'src="{image_path}"'
                    )

                # Загружаем HTML в редактор
                self.text_edit.setHtml(html_content)

            self.current_file = file_path
            self.text_edit.document().setModified(False)
            self.update_window_title()

            # Добавляем документ в историю
            self.recent_docs.add_document(file_path)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл: {str(e)}")

    def closeEvent(self, event):
        if self.maybe_save():
            # Очистка временных файлов
            if os.path.exists(self.temp_dir):
                try:
                    shutil.rmtree(self.temp_dir)
                except:
                    pass
            event.accept()
        else:
            event.ignore()


def main():
    parser = argparse.ArgumentParser(description=AppConfig.APP_NAME)
    parser.add_argument('-f', '--file', type=str, help='Путь к файлу для открытия')
    args = parser.parse_args()

    app = QApplication(sys.argv)

    # Применяем настройки
    settings_manager = SettingsManager()
    settings_manager.apply_theme(app)
    settings_manager.apply_font(app)

    # Устанавливаем иконку приложения
    if os.path.exists(AppConfig.APP_ICON):
        app.setWindowIcon(QIcon(AppConfig.APP_ICON))
    else:
        app.setWindowIcon(QIcon.fromTheme("accessories-text-editor"))

    # Создаем и показываем главное окно
    editor = DocumentEditor(file_to_open=args.file)
    editor.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
