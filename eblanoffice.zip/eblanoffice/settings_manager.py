#!/usr/bin/env python3
import json
import os
from pathlib import Path
from PySide6.QtGui import QFont, QPalette, QColor
from PySide6.QtWidgets import QApplication, QStyleFactory

class SettingsManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SettingsManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.settings_file = "settings.json"
        self.themes_dir = "themes"
        self.default_settings = {
            "theme": "system",
            "use_custom_font": False,
            "custom_font": "Arial",
            "font_size": 10,
            "recent_docs": []
        }
        self.settings = self.default_settings.copy()

        # Создаем папку themes если ее нет
        os.makedirs(self.themes_dir, exist_ok=True)

        self.load_settings()
        self._initialized = True

    def load_settings(self):
        """Загружает настройки из файла"""
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    self.settings.update(loaded)
            except Exception as e:
                print(f"Ошибка загрузки настроек: {e}")

    def save_settings(self):
        """Сохраняет настройки в файл"""
        try:
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Ошибка сохранения настроек: {e}")
            return False

    def get(self, key, default=None):
        """Получает значение настройки"""
        return self.settings.get(key, default)

    def set(self, key, value):
        """Устанавливает значение настройки"""
        self.settings[key] = value
        return self.save_settings()

    def get_available_themes(self):
        """Возвращает список доступных тем в формате [(отображаемое_имя, имя_файла), ...]"""
        themes = [("Системная тема", "system")]

        if os.path.exists(self.themes_dir):
            for file in os.listdir(self.themes_dir):
                if file.endswith('.json'):
                    file_path = os.path.join(self.themes_dir, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            theme_data = json.load(f)
                        # Используем ключ "name" из темы, если он есть, иначе имя файла без расширения
                        display_name = theme_data.get("name", file[:-5])
                    except Exception as e:
                        print(f"Ошибка загрузки темы {file}: {e}")
                        display_name = file[:-5]

                    themes.append((display_name, file[:-5]))

        return themes

    def apply_theme(self, app):
        """Применяет тему к приложению"""
        theme_name = self.settings.get("theme", "system")

        if theme_name == "system":
            app.setStyle(QStyleFactory.create(""))
            return

        theme_file = os.path.join(self.themes_dir, f"{theme_name}.json")
        if not os.path.exists(theme_file):
            return

        try:
            with open(theme_file, 'r', encoding='utf-8') as f:
                theme_data = json.load(f)

            # Применяем стили
            stylesheet = self._generate_stylesheet(theme_data)
            app.setStyleSheet(stylesheet)

            # Применяем палитру если нужно
            if "palette" in theme_data:
                self._apply_palette(app, theme_data["palette"])

        except Exception as e:
            print(f"Ошибка загрузки темы: {e}")

    def _generate_stylesheet(self, theme_data):
        """Генерирует таблицу стилей из темы"""
        styles = []

        # Базовые стили
        if "widget" in theme_data:
            styles.append(f"QWidget {{ {theme_data['widget']} }}")

        # Конкретные виджеты
        for widget, style in theme_data.items():
            if widget not in ["widget", "palette"]:
                styles.append(f"{widget} {{ {style} }}")

        return "\n".join(styles)

    def _apply_palette(self, app, palette_data):
        """Применяет цветовую палитру"""
        palette = QPalette()

        color_roles = {
            "window": QPalette.Window,
            "window_text": QPalette.WindowText,
            "base": QPalette.Base,
            "alternate_base": QPalette.AlternateBase,
            "text": QPalette.Text,
            "button": QPalette.Button,
            "button_text": QPalette.ButtonText,
            "bright_text": QPalette.BrightText,
            "highlight": QPalette.Highlight,
            "highlighted_text": QPalette.HighlightedText
        }

        for role_name, color_hex in palette_data.items():
            if role_name in color_roles:
                palette.setColor(color_roles[role_name], QColor(color_hex))

        app.setPalette(palette)

    def apply_font(self, app):
        """Применяет пользовательский шрифт"""
        if self.settings.get("use_custom_font", False):
            font_name = self.settings.get("custom_font", "Arial")
            font_size = self.settings.get("font_size", 10)

            font = QFont(font_name, font_size)
            app.setFont(font)

    def get_available_fonts(self):
        """Возвращает список доступных шрифтов"""
        from PySide6.QtGui import QFontDatabase

        # Получаем все шрифты из системы
        font_db = QFontDatabase()
        fonts = font_db.families()

        # Сортируем и возвращаем
        return sorted(fonts)
