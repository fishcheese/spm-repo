#!/usr/bin/env python3
import sys
import json
import zipfile
import os
import tempfile
import shutil
import math
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from settings_manager import SettingsManager

from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *

# ==============================
# КОНФИГУРАЦИЯ ПРОГРАММЫ
# ==============================
class AppConfig:
    APP_NAME = "EblanOffice Считалка"
    FILE_EXTENSION = ".eblcalc"
    FILE_FILTER = "Таблицы EblanOffice Считалка (*.eblcalc)"
    APP_ICON = "icons/calc.png"  # Используем иконку из папки icons
    DEFAULT_FILENAME = "Новая таблица"
    TEMP_PREFIX = "eblancalc_"
    FORMAT_VERSION = "1.0"

    # Файл для истории документов
    RECENT_DOCS_FILE = ".recentdocuments.json"
    MAX_RECENT_DOCS = 20

    # Настройки таблицы
    DEFAULT_ROWS = 100
    DEFAULT_COLS = 26  # A-Z
    COLUMN_WIDTH = 100
    ROW_HEIGHT = 30
# ==============================


# ==============================
# КЛАСС ДЛЯ РАБОТЫ С ИСТОРИЕЙ ДОКУМЕНТОВ
# ==============================
class RecentDocuments:
    def __init__(self, filename=AppConfig.RECENT_DOCS_FILE):
        self.filename = filename
        self.documents = []
        self.load()

    def load(self):
        """Загрузить историю документов из файла"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.documents = data.get("recent_documents", [])
            except:
                self.documents = []
        else:
            self.documents = []

    def save(self):
        """Сохранить историю документов в файл"""
        data = {"recent_documents": self.documents}
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except:
            return False

    def add_document(self, file_path):
        """Добавить документ в историю"""
        # Проверяем, существует ли файл
        if not os.path.exists(file_path):
            return False

        # Создаем запись о документе
        doc_info = {
            "path": file_path,
            "name": os.path.basename(file_path),
            "type": "spreadsheet",  # Тип таблицы
            "last_opened": datetime.now().isoformat()
        }

        # Удаляем старую запись, если она существует
        self.documents = [doc for doc in self.documents if doc["path"] != file_path]

        # Добавляем новую запись в начало
        self.documents.insert(0, doc_info)

        # Ограничиваем количество записей
        if len(self.documents) > AppConfig.MAX_RECENT_DOCS:
            self.documents = self.documents[:AppConfig.MAX_RECENT_DOCS]

        # Сохраняем изменения
        return self.save()


# ==============================
# СИСТЕМА ФУНКЦИЙ
# ==============================
class FunctionRegistry:
    """Реестр функций для таблицы"""

    def __init__(self):
        self.functions: Dict[str, Any] = {}
        self.register_default_functions()

    def register_default_functions(self):
        """Регистрация стандартных функций"""

        # Математические функции
        self.register("SUM", self.sum_func, "Сумма значений")
        self.register("AVERAGE", self.average_func, "Среднее значение")
        self.register("MAX", self.max_func, "Максимальное значение")
        self.register("MIN", self.min_func, "Минимальное значение")
        self.register("COUNT", self.count_func, "Количество чисел")

        # Тригонометрические функции (в радианах)
        self.register("SIN", math.sin, "Синус угла в радианах")
        self.register("COS", math.cos, "Косинус угла в радианах")
        self.register("TAN", math.tan, "Тангенс угла в радианах")
        self.register("COT", lambda x: 1 / math.tan(x) if math.tan(x) != 0 else float('nan'),
                     "Котангенс угла в радианах")

        # Другие математические функции
        self.register("SQRT", math.sqrt, "Квадратный корень")
        self.register("INT", lambda x: int(x), "Целая часть числа")
        self.register("ABS", abs, "Абсолютное значение")
        self.register("ROUND", round, "Округление числа")

        # Логические функции
        self.register("IF", self.if_func, "Условное выражение")
        self.register("AND", self.and_func, "Логическое И")
        self.register("OR", self.or_func, "Логическое ИЛИ")
        self.register("NOT", lambda x: not x, "Логическое НЕ")

    def register(self, name: str, func: callable, description: str = ""):
        """Регистрация новой функции"""
        self.functions[name.upper()] = {
            'func': func,
            'description': description,
            'name': name.upper()
        }

    def get(self, name: str) -> Optional[Dict]:
        """Получить функцию по имени"""
        return self.functions.get(name.upper())

    def list_functions(self) -> List[Dict]:
        """Список всех зарегистрированных функций"""
        return list(self.functions.values())

    # Реализации стандартных функций
    def sum_func(self, *args):
        """Суммирует все аргументы"""
        numbers = self._extract_numbers(args)
        return sum(numbers)

    def average_func(self, *args):
        """Среднее значение"""
        numbers = self._extract_numbers(args)
        if not numbers:
            return 0
        return sum(numbers) / len(numbers)

    def max_func(self, *args):
        """Максимальное значение"""
        numbers = self._extract_numbers(args)
        return max(numbers) if numbers else 0

    def min_func(self, *args):
        """Минимальное значение"""
        numbers = self._extract_numbers(args)
        return min(numbers) if numbers else 0

    def count_func(self, *args):
        """Количество чисел"""
        numbers = self._extract_numbers(args)
        return len(numbers)

    def if_func(self, condition, true_val, false_val):
        """Условное выражение"""
        return true_val if condition else false_val

    def and_func(self, *args):
        """Логическое И"""
        return all(args)

    def or_func(self, *args):
        """Логическое ИЛИ"""
        return any(args)

    def _extract_numbers(self, args):
        """Извлекает числа из аргументов, которые могут быть списками"""
        numbers = []
        for arg in args:
            if isinstance(arg, (list, tuple)):
                numbers.extend([x for x in arg if isinstance(x, (int, float))])
            elif isinstance(arg, (int, float)):
                numbers.append(arg)
        return numbers
# ==============================


# ==============================
# ПАРСЕР ФОРМУЛ
# ==============================
class FormulaParser:
    """Парсер формул для таблицы"""

    def __init__(self, function_registry: FunctionRegistry):
        self.function_registry = function_registry
        self.cell_values: Dict[str, Any] = {}

    def set_cell_values(self, cell_values: Dict[str, Any]):
        """Установить значения ячеек для вычисления формул"""
        self.cell_values = cell_values

    def parse(self, formula: str) -> Any:
        """Парсинг и вычисление формулы"""
        if not formula or not formula.startswith('='):
            return formula

        formula = formula[1:].strip()  # Убираем '='

        try:
            # Проверяем, является ли формула простым числом
            try:
                return float(formula) if '.' in formula else int(formula)
            except ValueError:
                pass

            # Проверяем, является ли формула ссылкой на ячейку
            if self._is_cell_reference(formula):
                return self._get_cell_value(formula)

            # Парсим функцию
            if '(' in formula and formula.endswith(')'):
                func_name, args_str = formula.split('(', 1)
                args_str = args_str[:-1]  # Убираем закрывающую скобку

                func_info = self.function_registry.get(func_name)
                if not func_info:
                    return f"#НЕИЗВЕСТНАЯ_ФУНКЦИЯ({func_name})"

                # Парсим аргументы
                args = self._parse_arguments(args_str)
                evaluated_args = [self._evaluate_arg(arg) for arg in args]

                # Выполняем функцию
                try:
                    return func_info['func'](*evaluated_args)
                except Exception as e:
                    return f"#ОШИБКА({str(e)})"

            # Парсим арифметические выражения
            return self._parse_expression(formula)

        except Exception as e:
            return f"#ОШИБКА({str(e)})"

    def _is_cell_reference(self, ref: str) -> bool:
        """Проверяет, является ли строка ссылкой на ячейку (A1, B2, etc.)"""
        if not ref:
            return False

        # Простая проверка: буквы затем цифры
        has_letter = False
        has_digit = False

        for char in ref:
            if char.isalpha():
                has_letter = True
            elif char.isdigit():
                has_digit = True
            else:
                return False

        return has_letter and has_digit

    def _get_cell_value(self, cell_ref: str) -> Any:
        """Получает значение ячейки по ссылке"""
        value = self.cell_values.get(cell_ref.upper(), "")

        # Если значение - формула, вычисляем ее
        if isinstance(value, str) and value.startswith('='):
            return self.parse(value)

        # Пытаемся преобразовать в число
        try:
            if isinstance(value, (int, float)):
                return value
            elif value:
                return float(value) if '.' in str(value) else int(value)
        except:
            pass

        return value

    def _parse_arguments(self, args_str: str) -> List[str]:
        """Парсит строку аргументов функции"""
        args = []
        current = ""
        paren_depth = 0

        for char in args_str:
            if char == ',' and paren_depth == 0:
                args.append(current.strip())
                current = ""
            else:
                if char == '(':
                    paren_depth += 1
                elif char == ')':
                    paren_depth -= 1
                current += char

        if current:
            args.append(current.strip())

        return args

    def _evaluate_arg(self, arg: str) -> Any:
        """Вычисляет значение аргумента"""
        arg = arg.strip()

        # Если это ссылка на диапазон ячеек (A1:B10)
        if ':' in arg:
            return self._parse_range(arg)

        # Если это ссылка на ячейку
        if self._is_cell_reference(arg):
            return self._get_cell_value(arg)

        # Если это число
        try:
            return float(arg) if '.' in arg else int(arg)
        except ValueError:
            pass

        # Если это строка (без кавычек)
        return arg

    def _parse_range(self, range_str: str) -> List[Any]:
        """Парсит диапазон ячеек (A1:B10)"""
        try:
            start, end = range_str.split(':')
            start_col, start_row = self._split_cell_ref(start)
            end_col, end_row = self._split_cell_ref(end)

            values = []
            for col in range(self._col_to_index(start_col), self._col_to_index(end_col) + 1):
                for row in range(int(start_row), int(end_row) + 1):
                    cell_ref = f"{self._index_to_col(col)}{row}"
                    values.append(self._get_cell_value(cell_ref))

            return values
        except:
            return []

    def _parse_expression(self, expr: str) -> Any:
        """Парсит простое арифметическое выражение"""
        # Упрощенный парсинг для демонстрации
        # В реальном приложении нужен полноценный парсер

        # Поддерживаем только +, -, *, /
        expr = expr.replace(' ', '')

        # Ищем операторы
        for op in ['+', '-', '*', '/']:
            if op in expr:
                parts = expr.split(op, 1)
                left = self._evaluate_arg(parts[0])
                right = self._evaluate_arg(parts[1])

                if op == '+':
                    return (left if isinstance(left, (int, float)) else 0) + \
                           (right if isinstance(right, (int, float)) else 0)
                elif op == '-':
                    return (left if isinstance(left, (int, float)) else 0) - \
                           (right if isinstance(right, (int, float)) else 0)
                elif op == '*':
                    return (left if isinstance(left, (int, float)) else 0) * \
                           (right if isinstance(right, (int, float)) else 0)
                elif op == '/':
                    right_num = right if isinstance(right, (int, float)) else 1
                    if right_num == 0:
                        return "#ДЕЛЕНИЕ_НА_0"
                    return (left if isinstance(left, (int, float)) else 0) / right_num

        return self._evaluate_arg(expr)

    def _split_cell_ref(self, cell_ref: str) -> Tuple[str, str]:
        """Разделяет ссылку на ячейку на колонку и строку"""
        col = ""
        row = ""

        for char in cell_ref:
            if char.isalpha():
                col += char.upper()
            elif char.isdigit():
                row += char

        return col, row

    def _col_to_index(self, col: str) -> int:
        """Преобразует букву колонки в индекс (A=0, B=1, ...)"""
        index = 0
        for char in col:
            index = index * 26 + (ord(char.upper()) - ord('A') + 1)
        return index - 1

    def _index_to_col(self, index: int) -> str:
        """Преобразует индекс в букву колонки"""
        col = ""
        index += 1

        while index > 0:
            index, remainder = divmod(index - 1, 26)
            col = chr(65 + remainder) + col

        return col
# ==============================


# ==============================
# ГЛАВНОЕ ОКНО ТАБЛИЦЫ
# ==============================
class SpreadsheetApp(QMainWindow):
    def __init__(self, file_to_open=None):
        super().__init__()
        self.current_file = file_to_open
        self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)
        self.cell_data: Dict[str, Any] = {}  # Хранит данные ячеек
        self.formula_parser = FormulaParser(FunctionRegistry())
        self.recent_docs = RecentDocuments()

        self.init_ui()
        self.update_formula_parser_values()

        # Если передан файл для открытия, загружаем его
        if file_to_open and os.path.exists(file_to_open):
            QTimer.singleShot(100, lambda: self.load_from_file(file_to_open))

    def init_ui(self):
        self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION} - {AppConfig.APP_NAME}")
        self.setGeometry(100, 100, 1200, 800)

        # Устанавливаем иконку
        if os.path.exists(AppConfig.APP_ICON):
            self.setWindowIcon(QIcon(AppConfig.APP_ICON))
        else:
            # Запасной вариант - иконка из темы
            self.setWindowIcon(QIcon.fromTheme("x-office-spreadsheet"))

        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Панель инструментов
        toolbar = QToolBar()
        self.addToolBar(toolbar)

        # Кнопки файлов
        new_action = QAction(QIcon.fromTheme("document-new"), "Новый", self)
        new_action.triggered.connect(self.new_document)
        toolbar.addAction(new_action)

        open_action = QAction(QIcon.fromTheme("document-open"), "Открыть", self)
        open_action.triggered.connect(self.open_document)
        toolbar.addAction(open_action)

        save_action = QAction(QIcon.fromTheme("document-save"), "Сохранить", self)
        save_action.triggered.connect(self.save_document)
        toolbar.addAction(save_action)

        save_as_action = QAction(QIcon.fromTheme("document-save-as"), "Сохранить как", self)
        save_as_action.triggered.connect(self.save_document_as)
        toolbar.addAction(save_as_action)

        toolbar.addSeparator()

        # Кнопка вставки функции
        func_action = QAction(QIcon.fromTheme("insert-function"), "Вставить функцию", self)
        func_action.triggered.connect(self.show_function_dialog)
        toolbar.addAction(func_action)

        toolbar.addSeparator()

        # Поле для ввода формулы
        # toolbar.addWidget(QLabel("Формула:"))
        self.formula_input = QLineEdit()
        self.formula_input.setMinimumWidth(400)
        self.formula_input.returnPressed.connect(self.apply_formula)
        toolbar.addWidget(self.formula_input)

        # Кнопка применения формулы
        apply_action = QAction("Применить", self)
        apply_action.triggered.connect(self.apply_formula)
        toolbar.addAction(apply_action)

        help_action = QAction(QIcon.fromTheme("help-contents"), "Справка по формулам", self)
        help_action.triggered.connect(self.show_formula_help)
        toolbar.addAction(help_action)

        # Таблица
        self.table = QTableWidget()
        self.table.setRowCount(AppConfig.DEFAULT_ROWS)
        self.table.setColumnCount(AppConfig.DEFAULT_COLS)

        # Устанавливаем заголовки колонок (A, B, C, ...)
        for i in range(AppConfig.DEFAULT_COLS):
            self.table.setHorizontalHeaderItem(i, QTableWidgetItem(chr(65 + i)))
            self.table.setColumnWidth(i, AppConfig.COLUMN_WIDTH)

        # Устанавливаем заголовки строк (1, 2, 3, ...)
        for i in range(AppConfig.DEFAULT_ROWS):
            self.table.setVerticalHeaderItem(i, QTableWidgetItem(str(i + 1)))
            self.table.setRowHeight(i, AppConfig.ROW_HEIGHT)

        self.table.cellChanged.connect(self.on_cell_changed)
        self.table.cellClicked.connect(self.on_cell_selected)
        self.table.currentCellChanged.connect(self.on_cell_selected)

        layout.addWidget(self.table)

        # Статус бар
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # Меню
        self.create_menu()

    def create_menu(self):
        menubar = self.menuBar()

        # Меню Файл
        file_menu = menubar.addMenu("Файл")

        new_action = QAction("Новый", self)
        new_action.triggered.connect(self.new_document)
        file_menu.addAction(new_action)

        open_action = QAction("Открыть", self)
        open_action.triggered.connect(self.open_document)
        file_menu.addAction(open_action)

        save_action = QAction("Сохранить", self)
        save_action.triggered.connect(self.save_document)
        file_menu.addAction(save_action)

        save_as_action = QAction("Сохранить как", self)
        save_as_action.triggered.connect(self.save_document_as)
        file_menu.addAction(save_as_action)

        file_menu.addSeparator()

        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Меню Правка
        edit_menu = menubar.addMenu("Правка")

        cut_action = QAction("Вырезать", self)
        cut_action.triggered.connect(self.cut_cells)
        edit_menu.addAction(cut_action)

        copy_action = QAction("Копировать", self)
        copy_action.triggered.connect(self.copy_cells)
        edit_menu.addAction(copy_action)

        paste_action = QAction("Вставить", self)
        paste_action.triggered.connect(self.paste_cells)
        edit_menu.addAction(paste_action)

        # Меню Формулы
        formula_menu = menubar.addMenu("Формулы")

        func_action = QAction("Вставить функцию...", self)
        func_action.triggered.connect(self.show_function_dialog)
        formula_menu.addAction(func_action)

        formula_menu.addSeparator()

        # Добавляем стандартные функции в меню
        functions = self.formula_parser.function_registry.list_functions()
        for func_info in functions[:10]:  # Показываем первые 10 функций
            action = QAction(func_info['name'], self)
            action.triggered.connect(lambda checked, f=func_info['name']: self.insert_function(f))
            formula_menu.addAction(action)

        # Меню Справка
        help_menu = menubar.addMenu("Справка")

        about_action = QAction("О программе", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def update_formula_parser_values(self):
        """Обновляет значения ячеек в парсере формул"""
        cell_values = {}
        for row in range(self.table.rowCount()):
            for col in range(self.table.columnCount()):
                cell_ref = f"{chr(65 + col)}{row + 1}"
                item = self.table.item(row, col)
                if item:
                    cell_values[cell_ref] = item.text()
        self.formula_parser.set_cell_values(cell_values)

    def on_cell_changed(self, row, col):
        """Обработчик изменения ячейки"""
        cell_ref = f"{chr(65 + col)}{row + 1}"
        item = self.table.item(row, col)

        if item:
            text = item.text()
            self.cell_data[cell_ref] = text

            # Если ячейка содержит формулу, вычисляем ее
            if text.startswith('='):
                self.update_formula_parser_values()
                result = self.formula_parser.parse(text)

                # Отображаем результат (но сохраняем формулу)
                self.table.blockSignals(True)
                item.setData(Qt.UserRole, text)  # Сохраняем формулу
                item.setText(str(result) if not isinstance(result, str) or not result.startswith('#') else result)
                self.table.blockSignals(False)

        self.update_window_title()

    def on_cell_selected(self, row, col, previous_row=None, previous_col=None):
        """Обработчик выбора ячейки"""
        cell_ref = f"{chr(65 + col)}{row + 1}"

        # Показываем ссылку на ячейку в статус баре
        self.status_bar.showMessage(f"Ячейка: {cell_ref}")

        # Показываем формулу в поле ввода
        item = self.table.item(row, col)
        if item:
            # Получаем формулу из UserRole или текст
            formula = item.data(Qt.UserRole)
            if formula:
                self.formula_input.setText(formula)
            else:
                self.formula_input.setText(item.text())
        else:
            self.formula_input.clear()

    def apply_formula(self):
        """Применяет формулу из поля ввода к текущей ячейке"""
        current_row = self.table.currentRow()
        current_col = self.table.currentColumn()

        if current_row >= 0 and current_col >= 0:
            formula = self.formula_input.text()
            item = QTableWidgetItem(formula)
            self.table.setItem(current_row, current_col, item)
            self.on_cell_changed(current_row, current_col)

    def show_function_dialog(self):
        """Показывает диалог выбора функции"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Вставить функцию")
        dialog.setModal(True)
        dialog.resize(400, 500)

        layout = QVBoxLayout()

        # Поиск
        search_layout = QHBoxLayout()
        search_label = QLabel("Поиск:")
        search_input = QLineEdit()
        search_input.textChanged.connect(lambda text: self.filter_functions(list_widget, text))
        search_layout.addWidget(search_label)
        search_layout.addWidget(search_input)
        layout.addLayout(search_layout)

        # Список функций
        list_widget = QListWidget()
        functions = self.formula_parser.function_registry.list_functions()

        for func_info in functions:
            item = QListWidgetItem(f"{func_info['name']} - {func_info['description']}")
            item.setData(Qt.UserRole, func_info['name'])
            list_widget.addItem(item)

        layout.addWidget(list_widget)

        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)

        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            selected_items = list_widget.selectedItems()
            if selected_items:
                func_name = selected_items[0].data(Qt.UserRole)
                self.insert_function(func_name)

    def filter_functions(self, list_widget: QListWidget, text: str):
        """Фильтрует список функций по тексту"""
        for i in range(list_widget.count()):
            item = list_widget.item(i)
            item.setHidden(text.lower() not in item.text().lower())

    def insert_function(self, func_name: str):
        """Вставляет функцию в поле ввода формулы"""
        current_text = self.formula_input.text()
        if not current_text.startswith('='):
            current_text = '='

        # Добавляем имя функции и скобки
        new_text = f"{current_text}{func_name}()"
        self.formula_input.setText(new_text)

        # Перемещаем курсор внутрь скобок
        cursor_pos = len(current_text) + len(func_name) + 1
        self.formula_input.setCursorPosition(cursor_pos)
        self.formula_input.setFocus()

    def cut_cells(self):
        """Вырезать ячейки"""
        self.copy_cells()
        self.clear_selected_cells()

    def copy_cells(self):
        """Копировать ячейки в буфер обмена"""
        selection = self.table.selectedRanges()
        if not selection:
            return

        data = []
        for range_ in selection:
            for row in range(range_.topRow(), range_.bottomRow() + 1):
                row_data = []
                for col in range(range_.leftColumn(), range_.rightColumn() + 1):
                    item = self.table.item(row, col)
                    row_data.append(item.text() if item else "")
                data.append('\t'.join(row_data))

        clipboard = QApplication.clipboard()
        clipboard.setText('\n'.join(data))

    def paste_cells(self):
        """Вставить ячейки из буфера обмена"""
        clipboard = QApplication.clipboard()
        text = clipboard.text()

        if not text:
            return

        current_row = self.table.currentRow()
        current_col = self.table.currentColumn()

        rows = text.strip().split('\n')
        for i, row in enumerate(rows):
            cells = row.split('\t')
            for j, cell in enumerate(cells):
                target_row = current_row + i
                target_col = current_col + j

                if target_row < self.table.rowCount() and target_col < self.table.columnCount():
                    item = QTableWidgetItem(cell)
                    self.table.setItem(target_row, target_col, item)
                    self.on_cell_changed(target_row, target_col)

    def clear_selected_cells(self):
        """Очистить выбранные ячейки"""
        for item in self.table.selectedItems():
            item.setText("")
            row = item.row()
            col = item.column()
            cell_ref = f"{chr(65 + col)}{row + 1}"
            if cell_ref in self.cell_data:
                del self.cell_data[cell_ref]

    def new_document(self):
        """Создать новый документ"""
        if self.maybe_save():
            self.table.clearContents()
            self.current_file = None
            self.cell_data.clear()
            self.formula_input.clear()
            self.update_window_title()

    def open_document(self):
        """Открыть документ"""
        if self.maybe_save():
            file_name, _ = QFileDialog.getOpenFileName(
                self, "Открыть таблицу", "",
                f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
            )

            if file_name:
                self.load_from_file(file_name)

    def save_document(self):
        """Сохранить документ"""
        if self.current_file:
            self.save_to_file(self.current_file)
        else:
            self.save_document_as()

    def save_document_as(self):
        """Сохранить документ как"""
        file_name, _ = QFileDialog.getSaveFileName(
            self, "Сохранить таблицу", "",
            f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
        )

        if file_name:
            if not file_name.endswith(AppConfig.FILE_EXTENSION):
                file_name += AppConfig.FILE_EXTENSION
            self.save_to_file(file_name)

    def maybe_save(self):
        """Проверка на необходимость сохранения"""
        if self.cell_data:
            reply = QMessageBox.question(
                self, "Сохранение",
                "Таблица была изменена. Сохранить изменения?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )

            if reply == QMessageBox.Save:
                self.save_document()
                return True
            elif reply == QMessageBox.Cancel:
                return False

        return True

    def save_to_file(self, file_path):
        """Сохранить таблицу в файл"""
        try:
            # Собираем данные ячеек
            cell_data = {}
            for row in range(self.table.rowCount()):
                for col in range(self.table.columnCount()):
                    item = self.table.item(row, col)
                    if item and item.text():
                        cell_ref = f"{chr(65 + col)}{row + 1}"
                        # Сохраняем формулу из UserRole или текст
                        formula = item.data(Qt.UserRole)
                        cell_data[cell_ref] = formula if formula else item.text()

            # Метаданные
            metadata = {
                "created": datetime.now().isoformat(),
                "modified": datetime.now().isoformat(),
                "cell_count": len(cell_data),
                "format": AppConfig.FORMAT_VERSION,
                "rows": self.table.rowCount(),
                "cols": self.table.columnCount()
            }

            # Создаем архив
            with zipfile.ZipFile(file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.writestr("cell_data.json", json.dumps(cell_data, indent=2, ensure_ascii=False))
                zipf.writestr("metadata.json", json.dumps(metadata, indent=2, ensure_ascii=False))

            self.current_file = file_path
            self.update_window_title()

            # Добавляем документ в историю
            self.recent_docs.add_document(file_path)

            QMessageBox.information(self, "Сохранение", "Таблица успешно сохранена!")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить файл: {str(e)}")

    def load_from_file(self, file_path):
        """Загрузить таблицу из файла"""
        try:
            self.table.clearContents()
            self.cell_data.clear()

            with zipfile.ZipFile(file_path, 'r') as zipf:
                # Загружаем данные ячеек
                cell_data_str = zipf.read("cell_data.json").decode('utf-8')
                cell_data = json.loads(cell_data_str)

                # Загружаем метаданные
                metadata_str = zipf.read("metadata.json").decode('utf-8')
                metadata = json.loads(metadata_str)

                # Восстанавливаем ячейки
                for cell_ref, value in cell_data.items():
                    # Парсим ссылку на ячейку
                    col_str = ""
                    row_str = ""

                    for char in cell_ref:
                        if char.isalpha():
                            col_str += char.upper()
                        elif char.isdigit():
                            row_str += char

                    if col_str and row_str:
                        col = self.formula_parser._col_to_index(col_str)
                        row = int(row_str) - 1

                        if row < self.table.rowCount() and col < self.table.columnCount():
                            item = QTableWidgetItem(value)

                            # Если это формула, сохраняем ее в UserRole
                            if isinstance(value, str) and value.startswith('='):
                                item.setData(Qt.UserRole, value)
                                # Вычисляем значение для отображения
                                self.update_formula_parser_values()
                                result = self.formula_parser.parse(value)
                                item.setText(str(result) if not isinstance(result, str) or not result.startswith('#') else result)

                            self.table.setItem(row, col, item)
                            self.cell_data[cell_ref] = value

            self.current_file = file_path
            self.update_window_title()

            # Добавляем документ в историю
            self.recent_docs.add_document(file_path)

            QMessageBox.information(self, "Загрузка", "Таблица успешно загружена!")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл: {str(e)}")

    def update_window_title(self):
        """Обновить заголовок окна"""
        modified = "*" if self.cell_data else ""
        if self.current_file:
            file_name = Path(self.current_file).name
            self.setWindowTitle(f"{file_name}{modified} - {AppConfig.APP_NAME}")
        else:
            self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION}{modified} - {AppConfig.APP_NAME}")

    def show_about(self):
        """Показать информацию о программе"""
        about_text = f"""
        <h2>{AppConfig.APP_NAME}</h2>
        <p>Простой табличный процессор с поддержкой формул.</p>
        <p>Поддерживаемые функции: SUM, AVERAGE, MAX, MIN, COUNT, SIN, COS, TAN, COT, SQRT, INT и другие.</p>
        <p>Версия формата: {AppConfig.FORMAT_VERSION}</p>
        <p>Для ввода формулы начните с символа "=".</p>
        """

        QMessageBox.about(self, "О программе", about_text)


    def show_formula_help(self):
        """Показать справку по формулам"""
        functions = self.formula_parser.function_registry.list_functions()

        help_text = f"""
        <h2>Справка по формулам</h2>
        <p>Для ввода формулы начните с символа "=".</p>

        <h3>Поддерживаемые функции:</h3>
        <table border="1" cellpadding="5">
        <tr><th>Функция</th><th>Описание</th><th>Пример</th></tr>
        """

        # Добавляем информацию о каждой функции
        for func_info in sorted(functions, key=lambda x: x['name']):
            func_name = func_info['name']
            description = func_info['description']

            # Примеры использования для разных функций
            examples = {
                "SUM": "=SUM(A1:A10)",
                "AVERAGE": "=AVERAGE(B1:B5)",
                "MAX": "=MAX(C1:C20)",
                "MIN": "=MIN(D1:D15)",
                "COUNT": "=COUNT(E1:E100)",
                "SIN": "=SIN(3.14159)",
                "COS": "=COS(0)",
                "TAN": "=TAN(0.785)",
                "COT": "=COT(0.5)",
                "SQRT": "=SQRT(16)",
                "INT": "=INT(3.9)",
                "ABS": "=ABS(-5)",
                "ROUND": "=ROUND(3.14159, 2)",
                "IF": "=IF(A1>10, \"Да\", \"Нет\")",
                "AND": "=AND(A1>0, B1<100)",
                "OR": "=OR(A1=0, B1=0)",
                "NOT": "=NOT(A1=0)"
            }

            example = examples.get(func_name, f"={func_name}(...)")
            help_text += f"<tr><td><b>{func_name}</b></td><td>{description}</td><td><code>{example}</code></td></tr>"

        help_text += """
        </table>

        <h3>Операторы:</h3>
        <ul>
        <li><b>+</b> - сложение (пример: =A1+B1)</li>
        <li><b>-</b> - вычитание (пример: =A1-B1)</li>
        <li><b>*</b> - умножение (пример: =A1*B1)</li>
        <li><b>/</b> - деление (пример: =A1/B1)</li>
        </ul>

        <h3>Ссылки на ячейки:</h3>
        <ul>
        <li><b>A1</b> - ссылка на ячейку A1</li>
        <li><b>A1:B10</b> - диапазон ячеек от A1 до B10</li>
        <li><b>Листы!A1</b> - в будущих версиях (пока не поддерживается)</li>
        </ul>

        <h3>Примеры сложных формул:</h3>
        <ul>
        <li><code>=SUM(A1:A10)*1.1</code> - сумма с наценкой 10%</li>
        <li><code>=IF(A1>B1, "Больше", "Меньше или равно")</code> - условное выражение</li>
        <li><code>=AVERAGE(A1:A10)+MAX(B1:B10)</code> - комбинация функций</li>
        </ul>
        """

        # Создаем диалоговое окно
        dialog = QDialog(self)
        dialog.setWindowTitle("Справка по формулам")
        dialog.setMinimumSize(700, 600)

        layout = QVBoxLayout()

        # Текстовое поле с HTML
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)
        text_edit.setHtml(help_text)
        layout.addWidget(text_edit)

        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Close)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)

        dialog.setLayout(layout)
        dialog.exec()

    def closeEvent(self, event):
        """Обработчик закрытия окна"""
        if self.maybe_save():
            # Очистка временных файлов
            if os.path.exists(self.temp_dir):
                try:
                    shutil.rmtree(self.temp_dir)
                except:
                    pass
            event.accept()
        else:
            event.ignore()


def main():
    parser = argparse.ArgumentParser(description=AppConfig.APP_NAME)
    parser.add_argument('-f', '--file', type=str, help='Путь к файлу для открытия')
    args = parser.parse_args()

    app = QApplication(sys.argv)

    # Применяем настройки
    settings_manager = SettingsManager()
    settings_manager.apply_theme(app)
    settings_manager.apply_font(app)

    # Устанавливаем иконку приложения
    if os.path.exists(AppConfig.APP_ICON):
        app.setWindowIcon(QIcon(AppConfig.APP_ICON))
    else:
        app.setWindowIcon(QIcon.fromTheme("x-office-spreadsheet"))

    # Создаем и показываем главное окно
    spreadsheet = SpreadsheetApp(file_to_open=args.file)
    spreadsheet.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
