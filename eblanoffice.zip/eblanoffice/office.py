#!/usr/bin/env python3
import sys
import os
import json
import subprocess
from pathlib import Path
from datetime import datetime

from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *

# Импортируем SettingsManager
from settings_manager import SettingsManager

# ==============================
# КОНФИГУРАЦИЯ ГЛАВНОГО ПРИЛОЖЕНИЯ
# ==============================
class OfficeConfig:
    APP_NAME = "EblanOffice"
    APP_ICON = "icons/office.png"
    RECENT_DOCS_FILE = ".recentdocuments.json"
    MAX_RECENT_DOCS = 20

    # Расширения файлов
    DOC_EXTENSION = ".ebldoc"
    CALC_EXTENSION = ".eblcalc"
    PRES_EXTENSION = ".eblpres"

    # Названия программ
    DOC_APP_NAME = "EblanOffice Глагол"
    CALC_APP_NAME = "EblanOffice Считалка"
    PRES_APP_NAME = "EblanOffice Презентатор"

    # Пути к иконкам
    DOC_ICON = "icons/doc.png"
    CALC_ICON = "icons/calc.png"
    PRES_ICON = "icons/pres.png"


# ==============================
# КЛАСС ДЛЯ РАБОТЫ С ИСТОРИЕЙ ДОКУМЕНТОВ
# ==============================
class RecentDocuments:
    def __init__(self, filename=OfficeConfig.RECENT_DOCS_FILE):
        self.filename = filename
        self.documents = []
        self.load()

    def load(self):
        """Загрузить историю документов из файла"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.documents = data.get("recent_documents", [])
            except:
                self.documents = []
        else:
            self.documents = []

    def save(self):
        """Сохранить историю документов в файл"""
        data = {"recent_documents": self.documents}
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except:
            return False

    def add_document(self, file_path):
        """Добавить документ в историю"""
        # Проверяем, существует ли файл
        if not os.path.exists(file_path):
            return False

        # Создаем запись о документе
        doc_info = {
            "path": file_path,
            "name": os.path.basename(file_path),
            "type": self.get_document_type(file_path),
            "last_opened": datetime.now().isoformat()
        }

        # Удаляем старую запись, если она существует
        self.documents = [doc for doc in self.documents if doc["path"] != file_path]

        # Добавляем новую запись в начало
        self.documents.insert(0, doc_info)

        # Ограничиваем количество записей
        if len(self.documents) > OfficeConfig.MAX_RECENT_DOCS:
            self.documents = self.documents[:OfficeConfig.MAX_RECENT_DOCS]

        # Сохраняем изменения
        return self.save()

    def clear(self):
        """Очистить историю документов"""
        self.documents = []
        return self.save()

    def get_document_type(self, file_path):
        """Определить тип документа по расширению"""
        if file_path.endswith(OfficeConfig.DOC_EXTENSION):
            return "document"
        elif file_path.endswith(OfficeConfig.CALC_EXTENSION):
            return "spreadsheet"
        elif file_path.endswith(OfficeConfig.PRES_EXTENSION):
            return "presentation"
        else:
            return "unknown"

    def get_documents_by_type(self, doc_type=None):
        """Получить документы определенного типа"""
        if doc_type:
            return [doc for doc in self.documents if doc["type"] == doc_type]
        return self.documents


# ==============================
# ДИАЛОГ НАСТРОЕК
# ==============================
class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        # Добавляем менеджер настроек
        self.settings_manager = SettingsManager()
        self.setWindowTitle("Настройки")
        self.setModal(True)
        self.setMinimumWidth(500)
        self.setMinimumHeight(400)
        self.init_ui()
        self.setup_connections()

    def init_ui(self):
        layout = QVBoxLayout()

        # Тема
        theme_group = QGroupBox("Тема")
        theme_layout = QVBoxLayout()

        theme_layout.addWidget(QLabel("Выберите тему:"))
        self.theme_combo = QComboBox()

        # Загружаем темы через SettingsManager
        themes = self.settings_manager.get_available_themes()
        for display_name, theme_id in themes:
            self.theme_combo.addItem(display_name, theme_id)

        # Загружаем текущую тему
        current_theme = self.settings_manager.get("theme", "system")
        index = self.theme_combo.findData(current_theme)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)

        theme_layout.addWidget(self.theme_combo)
        theme_group.setLayout(theme_layout)
        layout.addWidget(theme_group)

        # Шрифт
        font_group = QGroupBox("Шрифт")
        font_layout = QVBoxLayout()

        self.use_custom_font_checkbox = QCheckBox("Использовать пользовательский шрифт")
        font_layout.addWidget(self.use_custom_font_checkbox)

        font_layout.addWidget(QLabel("Выберите шрифт:"))

        # Контейнер для выбора шрифта
        font_container = QWidget()
        font_container_layout = QHBoxLayout(font_container)

        self.font_combo = QFontComboBox()  # Используем QFontComboBox вместо QComboBox
        self.font_combo.setMaximumWidth(300)

        # Загружаем все шрифты из системы (без создания экземпляра QFontDatabase)
        # QFontComboBox автоматически загружает доступные шрифты,
        # но если нужно получить список, используем статические методы
        font_families = QFontDatabase.families()  # Исправлено: статический метод
        self.font_combo.addItems(font_families)

        font_container_layout.addWidget(self.font_combo)
        font_container_layout.addStretch()

        font_layout.addWidget(font_container)

        # Пример текста для предпросмотра шрифта
        self.font_preview_label = QLabel("Пример текста: AaBbCc 123")
        self.font_preview_label.setFrameStyle(QFrame.Panel | QFrame.Sunken)
        self.font_preview_label.setAlignment(Qt.AlignCenter)
        self.font_preview_label.setMinimumHeight(60)
        font_layout.addWidget(self.font_preview_label)

        # Загружаем текущие настройки шрифта
        if os.path.exists("settings.json"):
            try:
                with open("settings.json", 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                    if settings.get("use_custom_font", False):
                        self.use_custom_font_checkbox.setChecked(True)
                        font_name = settings.get("custom_font", "Arial")

                        # Ищем шрифт в списке
                        index = self.font_combo.findText(font_name, Qt.MatchFixedString)
                        if index >= 0:
                            self.font_combo.setCurrentIndex(index)

                        # Обновляем предпросмотр
                        font = QFont(font_name)
                        self.font_preview_label.setFont(font)
            except:
                pass

        font_group.setLayout(font_layout)
        layout.addWidget(font_group)

        # Информационное сообщение
        info_label = QLabel(
            "Примечание: для полного применения изменений темы и шрифта "
            "может потребоваться перезапуск всех открытых приложений EblanOffice."
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #666; font-style: italic; padding: 5px;")
        layout.addWidget(info_label)

        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.setLayout(layout)

    def setup_connections(self):
        """Настройка сигналов"""
        self.use_custom_font_checkbox.toggled.connect(self.on_font_checkbox_toggled)
        self.font_combo.currentFontChanged.connect(self.on_font_changed)

        # Инициализируем состояние виджетов
        self.on_font_checkbox_toggled(self.use_custom_font_checkbox.isChecked())

    def on_font_checkbox_toggled(self, checked):
        """Обработчик изменения состояния чекбокса"""
        self.font_combo.setEnabled(checked)
        self.font_preview_label.setEnabled(checked)

    def on_font_changed(self, font):
        """Обработчик изменения выбранного шрифта"""
        # Обновляем предпросмотр шрифта
        current_font = QFont(font.family())
        current_font.setPointSize(12)
        self.font_preview_label.setFont(current_font)

    def get_settings(self):
        """Возвращает настройки из диалога"""
        return {
            "theme": self.theme_combo.currentData(),  # Используем currentData для получения ID темы
            "use_custom_font": self.use_custom_font_checkbox.isChecked(),
            "custom_font": self.font_combo.currentText()
        }


# ==============================
# ГЛАВНОЕ ОКНО ОФИСНОГО ПАКЕТА
# ==============================
class EblanOffice(QMainWindow):
    def __init__(self):
        super().__init__()
        self.recent_docs = RecentDocuments()
        self.settings_manager = SettingsManager()  # Добавляем менеджер настроек
        self.init_ui()
        self.load_recent_documents()
        self.apply_settings()

    def init_ui(self):
        self.setWindowTitle(OfficeConfig.APP_NAME)
        self.setGeometry(100, 100, 900, 600)

        # Устанавливаем иконку
        if os.path.exists(OfficeConfig.APP_ICON):
            self.setWindowIcon(QIcon(OfficeConfig.APP_ICON))

        # Создание центрального виджета
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # Левая панель (кнопки)
        left_panel = QWidget()
        left_panel.setMaximumWidth(200)
        left_layout = QVBoxLayout(left_panel)

        # Заголовок
        title_label = QLabel("EblanOffice")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        left_layout.addWidget(title_label)

        left_layout.addSpacing(20)

        # Кнопка "Открыть файл"
        self.open_file_btn = QPushButton("Открыть файл")
        self.open_file_btn.setIcon(QIcon.fromTheme("document-open"))
        self.open_file_btn.clicked.connect(self.open_file)
        left_layout.addWidget(self.open_file_btn)

        left_layout.addSpacing(10)

        # Разделитель
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        left_layout.addWidget(separator)

        left_layout.addSpacing(10)

        # Кнопка "Новый документ"
        self.new_doc_btn = QPushButton("Новый документ")
        self.new_doc_btn.setIcon(QIcon(OfficeConfig.DOC_ICON) if os.path.exists(OfficeConfig.DOC_ICON) else QIcon.fromTheme("accessories-text-editor"))
        self.new_doc_btn.clicked.connect(lambda: self.create_new_document("document"))
        left_layout.addWidget(self.new_doc_btn)

        # Кнопка "Новая таблица"
        self.new_calc_btn = QPushButton("Новая таблица")
        self.new_calc_btn.setIcon(QIcon(OfficeConfig.CALC_ICON) if os.path.exists(OfficeConfig.CALC_ICON) else QIcon.fromTheme("x-office-spreadsheet"))
        self.new_calc_btn.clicked.connect(lambda: self.create_new_document("spreadsheet"))
        left_layout.addWidget(self.new_calc_btn)

        # Кнопка "Новая презентация"
        self.new_pres_btn = QPushButton("Новая презентация")
        self.new_pres_btn.setIcon(QIcon(OfficeConfig.PRES_ICON) if os.path.exists(OfficeConfig.PRES_ICON) else QIcon.fromTheme("x-office-presentation"))
        self.new_pres_btn.clicked.connect(lambda: self.create_new_document("presentation"))
        left_layout.addWidget(self.new_pres_btn)

        left_layout.addSpacing(10)

        # Разделитель
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        left_layout.addWidget(separator)

        left_layout.addSpacing(10)

        # Кнопка настроек
        self.settings_btn = QPushButton("Настройки")
        self.settings_btn.setIcon(QIcon.fromTheme("preferences-system"))
        self.settings_btn.clicked.connect(self.show_settings)
        left_layout.addWidget(self.settings_btn)

        left_layout.addStretch()

        main_layout.addWidget(left_panel)

        # Правая панель (список недавних документов)
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        # Заголовок
        recent_label = QLabel("Недавние документы")
        recent_font = QFont()
        recent_font.setPointSize(14)
        recent_font.setBold(True)
        recent_label.setFont(recent_font)
        right_layout.addWidget(recent_label)

        # Список документов
        self.recent_list = QListWidget()
        self.recent_list.itemDoubleClicked.connect(self.open_recent_document)
        right_layout.addWidget(self.recent_list)

        # Панель с кнопкой очистки
        bottom_panel = QWidget()
        bottom_layout = QHBoxLayout(bottom_panel)
        bottom_layout.addStretch()

        self.clear_recent_btn = QPushButton("Очистить недавние документы")
        self.clear_recent_btn.clicked.connect(self.clear_recent_documents)
        bottom_layout.addWidget(self.clear_recent_btn)

        right_layout.addWidget(bottom_panel)

        main_layout.addWidget(right_panel, 1)

        # Меню
        self.create_menu()

    def create_menu(self):
        menubar = self.menuBar()

        # Меню Файл
        file_menu = menubar.addMenu("Файл")

        open_action = QAction("Открыть...", self)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        file_menu.addSeparator()

        new_doc_action = QAction("Новый документ", self)
        new_doc_action.triggered.connect(lambda: self.create_new_document("document"))
        file_menu.addAction(new_doc_action)

        new_calc_action = QAction("Новая таблица", self)
        new_calc_action.triggered.connect(lambda: self.create_new_document("spreadsheet"))
        file_menu.addAction(new_calc_action)

        new_pres_action = QAction("Новая презентация", self)
        new_pres_action.triggered.connect(lambda: self.create_new_document("presentation"))
        file_menu.addAction(new_pres_action)

        file_menu.addSeparator()

        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Меню Настройки
        settings_menu = menubar.addMenu("Настройки")

        settings_action = QAction("Настройки...", self)
        settings_action.triggered.connect(self.show_settings)
        settings_menu.addAction(settings_action)

        # Меню Справка
        help_menu = menubar.addMenu("Справка")

        about_action = QAction("О EblanOffice", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def load_recent_documents(self):
        """Загрузить список недавних документов"""
        self.recent_list.clear()

        for doc in self.recent_docs.documents:
            # Создаем элемент списка
            item_text = f"{doc['name']}\n{doc['path']}"
            item = QListWidgetItem(item_text)

            # Устанавливаем иконку в зависимости от типа
            if doc["type"] == "document":
                icon = QIcon(OfficeConfig.DOC_ICON) if os.path.exists(OfficeConfig.DOC_ICON) else QIcon.fromTheme("accessories-text-editor")
            elif doc["type"] == "spreadsheet":
                icon = QIcon(OfficeConfig.CALC_ICON) if os.path.exists(OfficeConfig.CALC_ICON) else QIcon.fromTheme("x-office-spreadsheet")
            elif doc["type"] == "presentation":
                icon = QIcon(OfficeConfig.PRES_ICON) if os.path.exists(OfficeConfig.PRES_ICON) else QIcon.fromTheme("x-office-presentation")
            else:
                icon = QIcon.fromTheme("text-x-generic")

            item.setIcon(icon)
            item.setData(Qt.UserRole, doc["path"])
            self.recent_list.addItem(item)

        # Если документов нет, показываем сообщение
        if self.recent_list.count() == 0:
            item = QListWidgetItem("Нет недавних документов")
            item.setFlags(Qt.NoItemFlags)
            self.recent_list.addItem(item)

    def open_file(self):
        file_filter = (
            f"Файлы EblanOffice (*{OfficeConfig.DOC_EXTENSION} *{OfficeConfig.CALC_EXTENSION} *{OfficeConfig.PRES_EXTENSION});;"
            "Все файлы (*)"
        )

        file_name, _ = QFileDialog.getOpenFileName(
            self, "Открыть документ", "",
            file_filter
        )

        if file_name:
            self.open_document_with_app(file_name)

    def open_recent_document(self, item):
        """Открыть документ из списка недавних"""
        file_path = item.data(Qt.UserRole)
        if file_path and os.path.exists(file_path):
            self.open_document_with_app(file_path)

    def open_document_with_app(self, file_path):
        """Открыть документ с помощью соответствующего приложения"""
        # Добавляем документ в историю
        self.recent_docs.add_document(file_path)

        # Определяем, какое приложение запускать
        if file_path.endswith(OfficeConfig.DOC_EXTENSION):
            app_script = "doc.py"
        elif file_path.endswith(OfficeConfig.CALC_EXTENSION):
            app_script = "calc.py"
        elif file_path.endswith(OfficeConfig.PRES_EXTENSION):
            app_script = "pres.py"
        else:
            QMessageBox.warning(self, "Ошибка", "Неизвестный тип файла")
            return

        # Запускаем приложение с аргументом -f
        try:
            # Для Windows
            if sys.platform == "win32":
                subprocess.Popen([sys.executable, app_script, "-f", file_path],
                               creationflags=subprocess.DETACHED_PROCESS)
            # Для Linux/Mac
            else:
                subprocess.Popen([sys.executable, app_script, "-f", file_path],
                               start_new_session=True)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось запустить приложение: {str(e)}")

    def create_new_document(self, doc_type):
        """Создать новый документ указанного типа"""
        if doc_type == "document":
            app_script = "doc.py"
            app_name = OfficeConfig.DOC_APP_NAME
        elif doc_type == "spreadsheet":
            app_script = "calc.py"
            app_name = OfficeConfig.CALC_APP_NAME
        elif doc_type == "presentation":
            app_script = "pres.py"
            app_name = OfficeConfig.PRES_APP_NAME
        else:
            return

        # Запускаем приложение без аргументов
        try:
            # Для Windows
            if sys.platform == "win32":
                subprocess.Popen([sys.executable, app_script],
                               creationflags=subprocess.DETACHED_PROCESS)
            # Для Linux/Mac
            else:
                subprocess.Popen([sys.executable, app_script],
                               start_new_session=True)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось запустить {app_name}: {str(e)}")

    def clear_recent_documents(self):
        """Очистить список недавних документов"""
        reply = QMessageBox.question(
            self, "Подтверждение",
            "Вы действительно хотите очистить список недавних документов?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            if self.recent_docs.clear():
                self.load_recent_documents()
                QMessageBox.information(self, "Успех", "Список недавних документов очищен")
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось очистить список")

    def show_about(self):
        """Показать информацию о программе"""
        about_text = f"""
        <h2>{OfficeConfig.APP_NAME}</h2>
        <p>Полноценный офисный пакет с тремя приложениями:</p>
        <ul>
            <li><b>Глагол</b> - текстовый редактор</li>
            <li><b>Считалка</b> - табличный процессор</li>
            <li><b>Презентатор</b> - редактор презентаций</li>
        </ul>
        <p>Все приложения используют собственный формат файлов:</p>
        <ul>
            <li>Документы: *{OfficeConfig.DOC_EXTENSION}</li>
            <li>Таблицы: *{OfficeConfig.CALC_EXTENSION}</li>
            <li>Презентации: *{OfficeConfig.PRES_EXTENSION}</li>
        </ul>
        """

        QMessageBox.about(self, "О программе", about_text)

    def apply_settings(self):
        """Применяет настройки темы и шрифта"""
        # Применяем тему через SettingsManager
        app = QApplication.instance()
        self.settings_manager.apply_theme(app)

        # Применяем шрифт через SettingsManager
        self.settings_manager.apply_font(app)

        # Также применяем шрифт к текущему окну
        if self.settings_manager.get("use_custom_font", False):
            font_name = self.settings_manager.get("custom_font", "Arial")
            font_size = self.settings_manager.get("font_size", 10)
            font = QFont(font_name, font_size)
            self.setFont(font)
            self._apply_font_to_children(self, font)

    def _apply_font_to_children(self, widget, font):
        """Рекурсивно применяет шрифт ко всем дочерним виджетам"""
        for child in widget.findChildren(QWidget):
            child.setFont(font)
            self._apply_font_to_children(child, font)

    def _generate_stylesheet(self, theme_data):
        """Генерирует таблицу стилей из темы"""
        styles = []

        # Базовые стили
        if "widget" in theme_data:
            styles.append(f"QWidget {{ {theme_data['widget']} }}")

        # Конкретные виджеты
        for widget, style in theme_data.items():
            if widget not in ["widget", "palette", "name"]:
                styles.append(f"{widget} {{ {style} }}")

        return "\n".join(styles)

    def show_settings(self):
        """Показывает диалог настроек"""
        dialog = SettingsDialog(self)
        if dialog.exec() == QDialog.Accepted:
            settings = dialog.get_settings()

            # Сохраняем настройки через SettingsManager
            for key, value in settings.items():
                self.settings_manager.set(key, value)

            # Применяем настройки
            self.apply_settings()

            # Показываем информационное сообщение о возможной необходимости перезапуска
            QMessageBox.information(
                self,
                "Настройки сохранены",
                "Настройки успешно сохранены!\n\n"
                "Примечание: Для полного применения изменений темы и шрифта "
                "может потребоваться перезапуск всех открытых приложений EblanOffice."
            )

    def closeEvent(self, event):
        """Обработчик закрытия окна"""
        event.accept()


# ==============================
# ТОЧКА ВХОДА
# ==============================
def main():
    app = QApplication(sys.argv)

    # Устанавливаем иконку приложения
    if os.path.exists(OfficeConfig.APP_ICON):
        app.setWindowIcon(QIcon(OfficeConfig.APP_ICON))

    # Создаем и показываем главное окно
    office = EblanOffice()
    office.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
