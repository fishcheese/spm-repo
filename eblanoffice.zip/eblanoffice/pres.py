#!/usr/bin/env python3
import sys
import zipfile
import json
import os
import tempfile
import shutil
import argparse
from pathlib import Path
from datetime import datetime
from enum import Enum
from settings_manager import SettingsManager

from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *

# ==============================
# КОНФИГУРАЦИЯ ПРОГРАММЫ
# ==============================
class AppConfig:
    # Название программы
    APP_NAME = "EblanOffice Презентатор"

    # Расширение презентаций по умолчанию
    FILE_EXTENSION = ".eblpres"
    FILE_FILTER = "Презентации EblanOffice Презентатор (*.eblpres)"

    # Иконка программы
    APP_ICON = "icons/pres.png"  # Используем иконку из папки icons

    # Название файла по умолчанию
    DEFAULT_FILENAME = "Безымянная_презентация"

    # Префикс для временной папки
    TEMP_PREFIX = "eblanpresenter_"

    # Версия формата
    FORMAT_VERSION = "1.0"

    # Файл для истории документов
    RECENT_DOCS_FILE = ".recentdocuments.json"
    MAX_RECENT_DOCS = 20

    # Настройки по умолчанию
    DEFAULT_TITLE_FONT_SIZE = 44
    DEFAULT_TEXT_FONT_SIZE = 32
    DEFAULT_BACKGROUND_COLOR = "#FFFFFF"
    DEFAULT_TEXT_COLOR = "#000000"


# ==============================
# КЛАСС ДЛЯ РАБОТЫ С ИСТОРИЕЙ ДОКУМЕНТОВ
# ==============================
class RecentDocuments:
    def __init__(self, filename=AppConfig.RECENT_DOCS_FILE):
        self.filename = filename
        self.documents = []
        self.load()

    def load(self):
        """Загрузить историю документов из файла"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.documents = data.get("recent_documents", [])
            except:
                self.documents = []
        else:
            self.documents = []

    def save(self):
        """Сохранить историю документов в файл"""
        data = {"recent_documents": self.documents}
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except:
            return False

    def add_document(self, file_path):
        """Добавить документ в историю"""
        # Проверяем, существует ли файл
        if not os.path.exists(file_path):
            return False

        # Создаем запись о документе
        doc_info = {
            "path": file_path,
            "name": os.path.basename(file_path),
            "type": "presentation",  # Тип презентации
            "last_opened": datetime.now().isoformat()
        }

        # Удаляем старую запись, если она существует
        self.documents = [doc for doc in self.documents if doc["path"] != file_path]

        # Добавляем новую запись в начало
        self.documents.insert(0, doc_info)

        # Ограничиваем количество записей
        if len(self.documents) > AppConfig.MAX_RECENT_DOCS:
            self.documents = self.documents[:AppConfig.MAX_RECENT_DOCS]

        # Сохраняем изменения
        return self.save()


# ==============================
# ТИПЫ СЛАЙДОВ
# ==============================
class SlideType(Enum):
    TITLE = 1  # Титульный слайд
    TITLE_AND_TEXT = 2  # Заголовок и текст
    TEXT_ONLY = 3  # Только текст
    TITLE_ONLY = 4  # Только заголовок
    TITLE_AND_TWO_COLUMNS = 5  # Заголовок и два блока текста
    TWO_COLUMNS = 6  # Два блока текста


# ==============================
# КЛАСС СЛАЙДА
# ==============================
class Slide:
    def __init__(self, slide_type=SlideType.TITLE):
        self.slide_type = slide_type
        self.title = ""
        self.text = ""
        self.text1 = ""  # Для двухколоночных слайдов
        self.text2 = ""  # Для двухколоночных слайдов
        self.background_color = None  # Исправлено: None по умолчанию вместо AppConfig.DEFAULT_BACKGROUND_COLOR
        self.background_image = None

        # Настройки шрифтов для текущего слайда
        self.title_font_family = None
        self.title_font_size = None
        self.title_font_bold = None
        self.title_color = None
        self.text_font_family = None
        self.text_font_size = None
        self.text_font_bold = None
        self.text_color = None

    def to_dict(self):
        """Преобразует слайд в словарь для сохранения"""
        return {
            "type": self.slide_type.value,
            "title": self.title,
            "text": self.text,
            "text1": self.text1,
            "text2": self.text2,
            "background_color": self.background_color,
            "background_image": self.background_image,
            # Сохраняем настройки шрифтов
            "title_font_family": self.title_font_family,
            "title_font_size": self.title_font_size,
            "title_font_bold": self.title_font_bold,
            "title_color": self.title_color,
            "text_font_family": self.text_font_family,
            "text_font_size": self.text_font_size,
            "text_font_bold": self.text_font_bold,
            "text_color": self.text_color
        }

    @staticmethod
    def from_dict(data):
        """Создает слайд из словаря"""
        slide = Slide(SlideType(data["type"]))
        slide.title = data.get("title", "")
        slide.text = data.get("text", "")
        slide.text1 = data.get("text1", "")
        slide.text2 = data.get("text2", "")
        slide.background_color = data.get("background_color", None)
        slide.background_image = data.get("background_image", None)
        # Загружаем настройки шрифтов
        slide.title_font_family = data.get("title_font_family", None)
        slide.title_font_size = data.get("title_font_size", None)
        slide.title_font_bold = data.get("title_font_bold", None)
        slide.title_color = data.get("title_color", None)
        slide.text_font_family = data.get("text_font_family", None)
        slide.text_font_size = data.get("text_font_size", None)
        slide.text_font_bold = data.get("text_font_bold", None)
        slide.text_color = data.get("text_color", None)
        return slide


# ==============================
# КЛАСС ТЕМЫ ПРЕЗЕНТАЦИИ
# ==============================
class PresentationTheme:
    def __init__(self):
        self.background_color = AppConfig.DEFAULT_BACKGROUND_COLOR
        self.background_image = None
        self.title_font_family = "Noto Sans"
        self.title_font_size = AppConfig.DEFAULT_TITLE_FONT_SIZE
        self.title_font_bold = True
        self.title_color = AppConfig.DEFAULT_TEXT_COLOR
        self.text_font_family = "Noto Sans"
        self.text_font_size = AppConfig.DEFAULT_TEXT_FONT_SIZE
        self.text_font_bold = False
        self.text_color = AppConfig.DEFAULT_TEXT_COLOR

    def to_dict(self):
        """Преобразует тему в словарь для сохранения"""
        return {
            "background_color": self.background_color,
            "background_image": self.background_image,
            "title_font_family": self.title_font_family,
            "title_font_size": self.title_font_size,
            "title_font_bold": self.title_font_bold,
            "title_color": self.title_color,
            "text_font_family": self.text_font_family,
            "text_font_size": self.text_font_size,
            "text_font_bold": self.text_font_bold,
            "text_color": self.text_color
        }

    @staticmethod
    def from_dict(data):
        """Создает тему из словаря"""
        theme = PresentationTheme()
        theme.background_color = data.get("background_color", AppConfig.DEFAULT_BACKGROUND_COLOR)
        theme.background_image = data.get("background_image", None)
        theme.title_font_family = data.get("title_font_family", "Noto Sans")
        theme.title_font_size = data.get("title_font_size", AppConfig.DEFAULT_TITLE_FONT_SIZE)
        theme.title_font_bold = data.get("title_font_bold", True)
        theme.title_color = data.get("title_color", AppConfig.DEFAULT_TEXT_COLOR)
        theme.text_font_family = data.get("text_font_family", "Noto Sans")
        theme.text_font_size = data.get("text_font_size", AppConfig.DEFAULT_TEXT_FONT_SIZE)
        theme.text_font_bold = data.get("text_font_bold", False)
        theme.text_color = data.get("text_color", AppConfig.DEFAULT_TEXT_COLOR)
        return theme


# ==============================
# ДИАЛОГ РЕДАКТИРОВАНИЯ СЛАЙДА
# ==============================
class EditSlideDialog(QDialog):
    def __init__(self, parent=None, slide=None):
        super().__init__(parent)
        self.slide = slide or Slide()
        self.setWindowTitle("Редактировать слайд")
        self.setModal(True)
        self.setMinimumWidth(500)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Выбор типа слайда
        type_layout = QHBoxLayout()
        type_layout.addWidget(QLabel("Тип слайда:"))
        self.type_combo = QComboBox()
        self.type_combo.addItem("Титульный слайд", SlideType.TITLE)
        self.type_combo.addItem("Заголовок и текст", SlideType.TITLE_AND_TEXT)
        self.type_combo.addItem("Только текст", SlideType.TEXT_ONLY)
        self.type_combo.addItem("Только заголовок", SlideType.TITLE_ONLY)
        self.type_combo.addItem("Заголовок и два блока", SlideType.TITLE_AND_TWO_COLUMNS)
        self.type_combo.addItem("Два блока текста", SlideType.TWO_COLUMNS)

        # Устанавливаем текущий тип
        for i in range(self.type_combo.count()):
            if self.type_combo.itemData(i) == self.slide.slide_type:
                self.type_combo.setCurrentIndex(i)
                break

        self.type_combo.currentIndexChanged.connect(self.update_ui)
        type_layout.addWidget(self.type_combo)
        type_layout.addStretch()
        layout.addLayout(type_layout)

        # Заголовок
        self.title_label = QLabel("Заголовок:")
        self.title_input = QTextEdit()
        self.title_input.setMaximumHeight(100)
        self.title_input.setPlainText(self.slide.title)
        layout.addWidget(self.title_label)
        layout.addWidget(self.title_input)

        # Основной текст
        self.text_label = QLabel("Текст:")
        self.text_input = QTextEdit()
        self.text_input.setPlainText(self.slide.text)
        layout.addWidget(self.text_label)
        layout.addWidget(self.text_input)

        # Два блока текста (скрыты по умолчанию)
        self.two_columns_widget = QWidget()
        two_columns_layout = QVBoxLayout(self.two_columns_widget)

        # Первый блок
        self.text1_label = QLabel("Текст слева:")
        self.text1_input = QTextEdit()
        self.text1_input.setPlainText(self.slide.text1)
        two_columns_layout.addWidget(self.text1_label)
        two_columns_layout.addWidget(self.text1_input)

        # Второй блок
        self.text2_label = QLabel("Текст справа:")
        self.text2_input = QTextEdit()
        self.text2_input.setPlainText(self.slide.text2)
        two_columns_layout.addWidget(self.text2_label)
        two_columns_layout.addWidget(self.text2_input)

        layout.addWidget(self.two_columns_widget)

        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.setLayout(layout)
        self.update_ui()

    def update_ui(self):
        """Обновляет видимость полей ввода в зависимости от типа слайда"""
        slide_type = self.type_combo.currentData()

        # Титульный слайд
        if slide_type == SlideType.TITLE:
            self.title_label.show()
            self.title_input.show()
            self.text_label.setText("Подзаголовок:")
            self.text_label.show()
            self.text_input.show()
            self.two_columns_widget.hide()

        # Заголовок и текст
        elif slide_type == SlideType.TITLE_AND_TEXT:
            self.title_label.show()
            self.title_input.show()
            self.text_label.setText("Текст:")
            self.text_label.show()
            self.text_input.show()
            self.two_columns_widget.hide()

        # Только текст
        elif slide_type == SlideType.TEXT_ONLY:
            self.title_label.hide()
            self.title_input.hide()
            self.text_label.setText("Текст:")
            self.text_label.show()
            self.text_input.show()
            self.two_columns_widget.hide()

        # Только заголовок
        elif slide_type == SlideType.TITLE_ONLY:
            self.title_label.show()
            self.title_input.show()
            self.text_label.hide()
            self.text_input.hide()
            self.two_columns_widget.hide()

        # Заголовок и два блока
        elif slide_type == SlideType.TITLE_AND_TWO_COLUMNS:
            self.title_label.show()
            self.title_input.show()
            self.text_label.hide()
            self.text_input.hide()
            self.two_columns_widget.show()

        # Два блока текста
        elif slide_type == SlideType.TWO_COLUMNS:
            self.title_label.hide()
            self.title_input.hide()
            self.text_label.hide()
            self.text_input.hide()
            self.two_columns_widget.show()

    def get_slide(self):
        """Возвращает отредактированный слайд"""
        slide_type = self.type_combo.currentData()
        self.slide.slide_type = slide_type
        self.slide.title = self.title_input.toPlainText()
        self.slide.text = self.text_input.toPlainText()
        self.slide.text1 = self.text1_input.toPlainText()
        self.slide.text2 = self.text2_input.toPlainText()
        return self.slide


# ==============================
# ДИАЛОГ ИЗМЕНЕНИЯ ВНЕШНЕГО ВИДА СЛАЙДА
# ==============================
class SlideAppearanceDialog(QDialog):
    def __init__(self, parent=None, slide=None, theme=None):
        super().__init__(parent)
        self.slide = slide or Slide()
        self.theme = theme or PresentationTheme()
        self.setWindowTitle("Изменить внешний вид слайда")
        self.setModal(True)
        self.setMinimumWidth(500)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Фон слайда
        bg_group = QGroupBox("Фон слайда")
        bg_layout = QVBoxLayout()

        # Цвет фона
        color_layout = QHBoxLayout()
        color_layout.addWidget(QLabel("Цвет фона:"))
        self.bg_color_button = QPushButton()
        self.bg_color_button.setFixedSize(50, 25)
        current_bg_color = self.slide.background_color or self.theme.background_color
        self.bg_color_button.setStyleSheet(f"background-color: {current_bg_color}; border: 1px solid #000;")
        self.bg_color_button.clicked.connect(self.choose_bg_color)
        color_layout.addWidget(self.bg_color_button)
        color_layout.addStretch()
        bg_layout.addLayout(color_layout)

        # Изображение фона
        image_layout = QHBoxLayout()
        image_layout.addWidget(QLabel("Изображение фона:"))
        self.bg_image_input = QLineEdit()
        self.bg_image_input.setReadOnly(True)
        self.bg_image_input.setText(self.slide.background_image or "")
        self.bg_image_button = QPushButton("Выбрать...")
        self.bg_image_button.clicked.connect(self.choose_bg_image)
        image_layout.addWidget(self.bg_image_input)
        image_layout.addWidget(self.bg_image_button)
        bg_layout.addLayout(image_layout)

        # Кнопка очистки изображения
        self.clear_bg_image_button = QPushButton("Удалить изображение")
        self.clear_bg_image_button.clicked.connect(self.clear_bg_image)
        bg_layout.addWidget(self.clear_bg_image_button)

        bg_group.setLayout(bg_layout)
        layout.addWidget(bg_group)

        # Шрифт заголовка
        title_group = QGroupBox("Шрифт заголовка (только для этого слайда)")
        title_layout = QGridLayout()

        title_layout.addWidget(QLabel("Шрифт:"), 0, 0)
        self.title_font_combo = QFontComboBox()
        # Используем настройки слайда, если они есть, иначе тему
        current_title_font = self.slide.title_font_family or self.theme.title_font_family
        self.title_font_combo.setCurrentFont(QFont(current_title_font))
        title_layout.addWidget(self.title_font_combo, 0, 1)

        title_layout.addWidget(QLabel("Размер:"), 1, 0)
        self.title_size_spin = QSpinBox()
        self.title_size_spin.setRange(8, 100)
        current_title_size = self.slide.title_font_size or self.theme.title_font_size
        self.title_size_spin.setValue(current_title_size)
        title_layout.addWidget(self.title_size_spin, 1, 1)

        title_layout.addWidget(QLabel("Цвет:"), 2, 0)
        self.title_color_button = QPushButton()
        self.title_color_button.setFixedSize(50, 25)
        current_title_color = self.slide.title_color or self.theme.title_color
        self.title_color_button.setStyleSheet(f"background-color: {current_title_color}; border: 1px solid #000;")
        self.title_color_button.clicked.connect(self.choose_title_color)
        title_layout.addWidget(self.title_color_button, 2, 1)

        self.title_bold_checkbox = QCheckBox("Жирный")
        current_title_bold = self.slide.title_font_bold if self.slide.title_font_bold is not None else self.theme.title_font_bold
        self.title_bold_checkbox.setChecked(current_title_bold)
        title_layout.addWidget(self.title_bold_checkbox, 3, 0, 1, 2)

        title_group.setLayout(title_layout)
        layout.addWidget(title_group)

        # Шрифт текста
        text_group = QGroupBox("Шрифт текста (только для этого слайда)")
        text_layout = QGridLayout()

        text_layout.addWidget(QLabel("Шрифт:"), 0, 0)
        self.text_font_combo = QFontComboBox()
        # Используем настройки слайда, если они есть, иначе тему
        current_text_font = self.slide.text_font_family or self.theme.text_font_family
        self.text_font_combo.setCurrentFont(QFont(current_text_font))
        text_layout.addWidget(self.text_font_combo, 0, 1)

        text_layout.addWidget(QLabel("Размер:"), 1, 0)
        self.text_size_spin = QSpinBox()
        self.text_size_spin.setRange(8, 100)
        current_text_size = self.slide.text_font_size or self.theme.text_font_size
        self.text_size_spin.setValue(current_text_size)
        text_layout.addWidget(self.text_size_spin, 1, 1)

        text_layout.addWidget(QLabel("Цвет:"), 2, 0)
        self.text_color_button = QPushButton()
        self.text_color_button.setFixedSize(50, 25)
        current_text_color = self.slide.text_color or self.theme.text_color
        self.text_color_button.setStyleSheet(f"background-color: {current_text_color}; border: 1px solid #000;")
        self.text_color_button.clicked.connect(self.choose_text_color)
        text_layout.addWidget(self.text_color_button, 2, 1)

        self.text_bold_checkbox = QCheckBox("Жирный")
        current_text_bold = self.slide.text_font_bold if self.slide.text_font_bold is not None else self.theme.text_font_bold
        self.text_bold_checkbox.setChecked(current_text_bold)
        text_layout.addWidget(self.text_bold_checkbox, 3, 0, 1, 2)

        text_group.setLayout(text_layout)
        layout.addWidget(text_group)

        # Кнопка "Применить ко всем слайдам" (только для фона)
        self.apply_to_all_button = QPushButton("Применить фон ко всем слайдам")
        self.apply_to_all_button.clicked.connect(self.apply_background_to_all)
        layout.addWidget(self.apply_to_all_button)

        # Кнопки OK и Cancel
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.setLayout(layout)

    def choose_bg_color(self):
        current_bg_color = self.slide.background_color or self.theme.background_color
        color = QColorDialog.getColor(QColor(current_bg_color), self)
        if color.isValid():
            self.slide.background_color = color.name()
            self.bg_color_button.setStyleSheet(f"background-color: {self.slide.background_color}; border: 1px solid #000;")

    def choose_bg_image(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Выберите изображение", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.svg *.webp);;Все файлы (*)"
        )
        if file_name:
            self.slide.background_image = file_name
            self.bg_image_input.setText(file_name)

    def clear_bg_image(self):
        self.slide.background_image = None
        self.bg_image_input.clear()

    def choose_title_color(self):
        current_title_color = self.slide.title_color or self.theme.title_color
        color = QColorDialog.getColor(QColor(current_title_color), self)
        if color.isValid():
            self.slide.title_color = color.name()
            self.title_color_button.setStyleSheet(f"background-color: {self.slide.title_color}; border: 1px solid #000;")

    def choose_text_color(self):
        current_text_color = self.slide.text_color or self.theme.text_color
        color = QColorDialog.getColor(QColor(current_text_color), self)
        if color.isValid():
            self.slide.text_color = color.name()
            self.text_color_button.setStyleSheet(f"background-color: {self.slide.text_color}; border: 1px solid #000;")

    def apply_background_to_all(self):
        """Применить настройки фона текущего слайда ко всем слайдам"""
        reply = QMessageBox.question(
            self, "Применить фон ко всем слайдам",
            "Вы уверены, что хотите применить настройки фона этого слайда ко всем слайдам?\n\nПримечание: настройки шрифтов применяются только к текущему слайду.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.accept_with_apply = True
            self.accept()

    def get_slide(self):
        """Возвращает слайд с измененными настройками"""
        # Сохраняем настройки шрифтов в слайд
        self.slide.title_font_family = self.title_font_combo.currentFont().family()
        self.slide.title_font_size = self.title_size_spin.value()
        self.slide.title_font_bold = self.title_bold_checkbox.isChecked()
        self.slide.text_font_family = self.text_font_combo.currentFont().family()
        self.slide.text_font_size = self.text_size_spin.value()
        self.slide.text_font_bold = self.text_bold_checkbox.isChecked()

        return self.slide


# ==============================
# РЕЖИМ ДЕМОНСТРАЦИИ
# ==============================
class SlideShow(QMainWindow):
    def __init__(self, slides, theme, parent=None):
        super().__init__(parent)
        self.slides = slides
        self.theme = theme
        self.current_slide_index = 0

        # Создаем завершающий слайд
        self.ending_slide = Slide(SlideType.TEXT_ONLY)
        self.ending_slide.text = "Щёлкните мышью для выхода из презентации."
        self.ending_slide.background_color = "#000000"
        self.ending_slide.text_color = "#FFFFFF"
        self.ending_slide.text_font_size = 20
        self.ending_slide.text_font_family = "Noto Sans"

        self.setWindowTitle("Демонстрация")

        # Отключаем все стили темы
        self.setStyleSheet("QMainWindow { background: transparent; border: none; }")
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        self.central_widget = QWidget()
        self.central_widget.setStyleSheet("background: transparent; border: none;")
        self.setCentralWidget(self.central_widget)

        self.showFullScreen()
        self.setCursor(Qt.BlankCursor)

    def paintEvent(self, event):
        """Отрисовывает текущий слайд"""
        painter = QPainter(self)

        # Заливаем фон прозрачным цветом перед отрисовкой слайда
        painter.fillRect(self.rect(), Qt.transparent)

        # Определяем, какой слайд отображать
        slide_to_show = None
        if self.current_slide_index < len(self.slides):
            slide_to_show = self.slides[self.current_slide_index]
        else:
            # Показываем завершающий слайд
            slide_to_show = self.ending_slide

        self.draw_slide(painter, slide_to_show)

        # Отображаем номер слайда (только для настоящих слайдов)
        if self.current_slide_index < len(self.slides):
            painter.setPen(QColor(128, 128, 128))
            painter.setFont(QFont("Noto Sans", 12))
            slide_text = f"{self.current_slide_index + 1} / {len(self.slides)}"
            painter.drawText(self.width() - 100, self.height() - 20, slide_text)

    def draw_slide(self, painter, slide):
        """Отрисовывает конкретный слайд"""
        # Определяем фон для текущего слайда
        if slide.background_image and os.path.exists(slide.background_image):
            # Если у слайда есть свое изображение фона
            pixmap = QPixmap(slide.background_image)
            if not pixmap.isNull():
                scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                x = (self.width() - scaled_pixmap.width()) // 2
                y = (self.height() - scaled_pixmap.height()) // 2
                painter.drawPixmap(x, y, scaled_pixmap)
        elif slide.background_color:
            # Если у слайда есть свой цвет фона
            painter.fillRect(self.rect(), QColor(slide.background_color))
        elif self.theme.background_image and os.path.exists(self.theme.background_image):
            # Если есть изображение фона в теме
            pixmap = QPixmap(self.theme.background_image)
            if not pixmap.isNull():
                scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                x = (self.width() - scaled_pixmap.width()) // 2
                y = (self.height() - scaled_pixmap.height()) // 2
                painter.drawPixmap(x, y, scaled_pixmap)
        else:
            # Используем цвет фона из темы
            painter.fillRect(self.rect(), QColor(self.theme.background_color))

        # Устанавливаем шрифт для текста (используем настройки слайда или темы)
        text_font_family = slide.text_font_family or self.theme.text_font_family
        text_font_size = slide.text_font_size or self.theme.text_font_size
        text_font_bold = slide.text_font_bold if slide.text_font_bold is not None else self.theme.text_font_bold

        text_font = QFont(text_font_family, text_font_size)
        text_font.setBold(text_font_bold)

        # Цвета (используем настройки слайда или темы)
        text_color = slide.text_color or self.theme.text_color

        # Для завершающего слайда используем специальную отрисовку
        if slide == self.ending_slide:
            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(50, 50, self.width() - 100, self.height() - 100)
            painter.drawText(text_rect, Qt.AlignCenter | Qt.TextWordWrap, slide.text)
            return

        # Для обычных слайдов продолжаем стандартную отрисовку
        title_font_family = slide.title_font_family or self.theme.title_font_family
        title_font_size = slide.title_font_size or self.theme.title_font_size
        title_font_bold = slide.title_font_bold if slide.title_font_bold is not None else self.theme.title_font_bold

        title_font = QFont(title_font_family, title_font_size)
        title_font.setBold(title_font_bold)

        title_color = slide.title_color or self.theme.title_color

        # Отображаем в зависимости от типа слайда
        if slide.slide_type == SlideType.TITLE:
            # Титульный слайд - заголовок по центру, текст снизу
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(0, self.height() // 3, self.width(), 100)
            painter.drawText(title_rect, Qt.AlignCenter, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(0, self.height() // 2, self.width(), 100)
            painter.drawText(text_rect, Qt.AlignCenter, slide.text)

        elif slide.slide_type == SlideType.TITLE_AND_TEXT:
            # Заголовок сверху, текст занимает большую часть
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(50, 50, self.width() - 100, 100)
            painter.drawText(title_rect, Qt.AlignLeft, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(50, 150, self.width() - 100, self.height() - 200)
            painter.drawText(text_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text)

        elif slide.slide_type == SlideType.TEXT_ONLY:
            # Только текст на весь слайд
            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(50, 50, self.width() - 100, self.height() - 100)
            painter.drawText(text_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text)

        elif slide.slide_type == SlideType.TITLE_ONLY:
            # Только заголовок сверху
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(50, 50, self.width() - 100, self.height() - 100)
            painter.drawText(title_rect, Qt.AlignLeft, slide.title)

        elif slide.slide_type == SlideType.TITLE_AND_TWO_COLUMNS:
            # Заголовок сверху, два блока текста
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(50, 50, self.width() - 100, 100)
            painter.drawText(title_rect, Qt.AlignLeft, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))

            # Левый блок
            left_rect = QRect(50, 150, (self.width() - 150) // 2, self.height() - 200)
            painter.drawText(left_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text1)

            # Правый блок
            right_rect = QRect((self.width() - 150) // 2 + 100, 150, (self.width() - 150) // 2, self.height() - 200)
            painter.drawText(right_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text2)

        elif slide.slide_type == SlideType.TWO_COLUMNS:
            # Два блока текста без заголовка
            painter.setFont(text_font)
            painter.setPen(QColor(text_color))

            # Левый блок
            left_rect = QRect(50, 50, (self.width() - 150) // 2, self.height() - 100)
            painter.drawText(left_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text1)

            # Правый блок
            right_rect = QRect((self.width() - 150) // 2 + 100, 50, (self.width() - 150) // 2, self.height() - 100)
            painter.drawText(right_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text2)

    def keyPressEvent(self, event):
        """Обработка клавиш для навигации"""
        if event.key() == Qt.Key_Escape:
            self.close()
        elif event.key() == Qt.Key_Right or event.key() == Qt.Key_Space:
            if self.current_slide_index < len(self.slides):
                self.next_slide()
            else:
                # На завершающем слайде - выход
                self.close()
        elif event.key() == Qt.Key_Left:
            if self.current_slide_index < len(self.slides):
                self.prev_slide()
            else:
                # На завершающем слайде - возврат к последнему слайду
                self.current_slide_index = len(self.slides) - 1
                self.update()
        else:
            super().keyPressEvent(event)

    def mousePressEvent(self, event):
        """Обработка кликов мыши для навигации"""
        if event.button() == Qt.LeftButton:
            if self.current_slide_index < len(self.slides):
                self.next_slide()
            else:
                # На завершающем слайде - выход
                self.close()

    def next_slide(self):
        """Переход к следующему слайду"""
        if self.current_slide_index < len(self.slides):
            self.current_slide_index += 1
            self.update()

    def prev_slide(self):
        """Переход к предыдущему слайду"""
        if self.current_slide_index > 0:
            self.current_slide_index -= 1
            self.update()


# ==============================
# ГЛАВНОЕ ОКНО РЕДАКТОРА
# ==============================
class PresentationEditor(QMainWindow):
    def __init__(self, file_to_open=None):
        super().__init__()
        self.current_file = file_to_open
        self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)
        self.slides = []  # Список слайдов
        self.current_slide_index = 0  # Индекс текущего слайда
        self.theme = PresentationTheme()  # Тема презентации
        self.recent_docs = RecentDocuments()

        self.init_ui()

        # Если передан файл для открытия, загружаем его
        if file_to_open and os.path.exists(file_to_open):
            QTimer.singleShot(100, lambda: self.load_from_file(file_to_open))

    def init_ui(self):
        self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION} - {AppConfig.APP_NAME}")
        self.setGeometry(100, 100, 1200, 800)

        # Устанавливаем иконку
        if os.path.exists(AppConfig.APP_ICON):
            self.setWindowIcon(QIcon(AppConfig.APP_ICON))
        else:
            # Запасной вариант - иконка из темы
            self.setWindowIcon(QIcon.fromTheme("x-office-presentation"))

        # Создание центрального виджета
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # Левая панель
        left_panel = QWidget()
        left_panel.setMaximumWidth(250)
        left_layout = QVBoxLayout(left_panel)

        # Список слайдов
        left_layout.addWidget(QLabel("Слайды:"))
        self.slides_list = QListWidget()
        self.slides_list.currentRowChanged.connect(self.change_current_slide)
        left_layout.addWidget(self.slides_list)

        # Кнопки управления слайдами
        slide_buttons_layout = QHBoxLayout()
        self.prev_slide_btn = QPushButton("←")
        self.prev_slide_btn.clicked.connect(self.prev_slide)
        self.next_slide_btn = QPushButton("→")
        self.next_slide_btn.clicked.connect(self.next_slide)
        slide_buttons_layout.addWidget(self.prev_slide_btn)
        slide_buttons_layout.addWidget(self.next_slide_btn)
        left_layout.addLayout(slide_buttons_layout)

        self.new_slide_btn = QPushButton("Новый слайд")
        self.new_slide_btn.clicked.connect(self.new_slide)
        left_layout.addWidget(self.new_slide_btn)

        self.delete_slide_btn = QPushButton("Удалить слайд")
        self.delete_slide_btn.clicked.connect(self.delete_slide)
        left_layout.addWidget(self.delete_slide_btn)

        left_layout.addStretch()
        main_layout.addWidget(left_panel)

        # Центральная панель (предпросмотр)
        center_panel = QWidget()
        center_layout = QVBoxLayout(center_panel)

        # Панель предпросмотра слайда
        self.slide_preview = SlidePreviewWidget(self)
        center_layout.addWidget(self.slide_preview)

        main_layout.addWidget(center_panel, 1)

        # Создание тулбара
        self.create_toolbar()

        # Создание начального слайда
        self.new_slide()

    def create_toolbar(self):
        """Создает панель инструментов"""
        toolbar = QToolBar()
        self.addToolBar(toolbar)

        # Кнопки файлов
        new_action = QAction(QIcon.fromTheme("document-new"), "Новый", self)
        new_action.triggered.connect(self.new_presentation)
        toolbar.addAction(new_action)

        open_action = QAction(QIcon.fromTheme("document-open"), "Открыть", self)
        open_action.triggered.connect(self.open_presentation)
        toolbar.addAction(open_action)

        save_action = QAction(QIcon.fromTheme("document-save"), "Сохранить", self)
        save_action.triggered.connect(self.save_presentation)
        toolbar.addAction(save_action)

        save_as_action = QAction(QIcon.fromTheme("document-save-as"), "Сохранить как", self)
        save_as_action.triggered.connect(self.save_presentation_as)
        toolbar.addAction(save_as_action)

        toolbar.addSeparator()

        # Кнопка демонстрации
        show_action = QAction(QIcon.fromTheme("media-playback-start"), "Демонстрация", self)
        show_action.triggered.connect(self.start_slideshow)
        toolbar.addAction(show_action)

        toolbar.addSeparator()

        # Кнопка изменения внешнего вида слайда
        slide_appearance_action = QAction(QIcon.fromTheme("preferences-desktop-theme"), "Изменить внешний вид слайда", self)
        slide_appearance_action.triggered.connect(self.change_slide_appearance)
        toolbar.addAction(slide_appearance_action)

        # Кнопка редактирования слайда
        edit_slide_action = QAction(QIcon.fromTheme("document-edit"), "Редактировать слайд", self)
        edit_slide_action.triggered.connect(self.edit_slide)
        toolbar.addAction(edit_slide_action)

    def new_presentation(self):
        """Создание новой презентации"""
        if self.maybe_save():
            self.slides = []
            self.current_slide_index = 0
            self.theme = PresentationTheme()
            self.current_file = None
            self.slides_list.clear()
            self.update_window_title()
            self.new_slide()

            # Очищаем временную папку
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
            self.temp_dir = tempfile.mkdtemp(prefix=AppConfig.TEMP_PREFIX)

    def open_presentation(self):
        """Открытие презентации"""
        if self.maybe_save():
            file_name, _ = QFileDialog.getOpenFileName(
                self, "Открыть презентацию", "",
                f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
            )

            if file_name:
                self.load_from_file(file_name)

    def save_presentation(self):
        """Сохранение презентации"""
        if self.current_file:
            self.save_to_file(self.current_file)
        else:
            self.save_presentation_as()

    def save_presentation_as(self):
        """Сохранение презентации как..."""
        file_name, _ = QFileDialog.getSaveFileName(
            self, "Сохранить презентацию", "",
            f"{AppConfig.FILE_FILTER} (*{AppConfig.FILE_EXTENSION});;Все файлы (*)"
        )

        if file_name:
            if not file_name.endswith(AppConfig.FILE_EXTENSION):
                file_name += AppConfig.FILE_EXTENSION
            self.save_to_file(file_name)

    def maybe_save(self):
        """Проверка необходимости сохранения (упрощенная)"""
        # В реальном приложении здесь нужно проверять, были ли изменения
        return True

    def new_slide(self):
        """Создание нового слайда"""
        slide = Slide()
        self.slides.append(slide)
        self.current_slide_index = len(self.slides) - 1
        self.update_slides_list()
        self.slide_preview.update()

    def delete_slide(self):
        """Удаление текущего слайда"""
        if len(self.slides) > 1 and self.current_slide_index < len(self.slides):
            self.slides.pop(self.current_slide_index)
            if self.current_slide_index >= len(self.slides):
                self.current_slide_index = len(self.slides) - 1
            self.update_slides_list()
            self.slide_preview.update()

    def prev_slide(self):
        """Переход к предыдущему слайду"""
        if self.current_slide_index > 0:
            self.current_slide_index -= 1
            self.slides_list.setCurrentRow(self.current_slide_index)
            self.slide_preview.update()

    def next_slide(self):
        """Переход к следующему слайду"""
        if self.current_slide_index < len(self.slides) - 1:
            self.current_slide_index += 1
            self.slides_list.setCurrentRow(self.current_slide_index)
            self.slide_preview.update()

    def change_current_slide(self, index):
        """Изменение текущего слайда"""
        if 0 <= index < len(self.slides):
            self.current_slide_index = index
            self.slide_preview.update()

    def edit_slide(self):
        """Редактирование текущего слайда"""
        if self.current_slide_index < len(self.slides):
            slide = self.slides[self.current_slide_index]
            dialog = EditSlideDialog(self, slide)
            if dialog.exec() == QDialog.Accepted:
                edited_slide = dialog.get_slide()
                # Копируем изменения в текущий слайд
                self.slides[self.current_slide_index] = edited_slide
                self.update_slides_list()
                self.slide_preview.update()

    def change_slide_appearance(self):
        """Изменение внешнего вида текущего слайда"""
        if self.current_slide_index < len(self.slides):
            slide = self.slides[self.current_slide_index]
            dialog = SlideAppearanceDialog(self, slide, self.theme)
            if dialog.exec() == QDialog.Accepted:
                edited_slide = dialog.get_slide()

                # Проверяем, была ли нажата кнопка "Применить ко всем слайдам"
                if hasattr(dialog, 'accept_with_apply') and dialog.accept_with_apply:
                    # Применяем настройки фона ко всем слайдам
                    for s in self.slides:
                        s.background_color = edited_slide.background_color
                        s.background_image = edited_slide.background_image

                # Копируем изменения в текущий слайд
                self.slides[self.current_slide_index] = edited_slide
                self.update_slides_list()
                self.slide_preview.update()

    def start_slideshow(self):
        """Запуск демонстрации"""
        if self.slides:
            self.slideshow = SlideShow(self.slides, self.theme, self)
            self.slideshow.show()

    def update_slides_list(self):
        """Обновление списка слайдов"""
        self.slides_list.clear()
        for i, slide in enumerate(self.slides):
            slide_title = slide.title if slide.title else f"Слайд {i+1}"
            self.slides_list.addItem(f"{i+1}. {slide_title[:30]}")
        self.slides_list.setCurrentRow(self.current_slide_index)

    def update_window_title(self):
        """Обновление заголовка окна"""
        modified = "*" if self.is_modified() else ""
        if self.current_file:
            file_name = Path(self.current_file).name
            self.setWindowTitle(f"{file_name}{modified} - {AppConfig.APP_NAME}")
        else:
            self.setWindowTitle(f"{AppConfig.DEFAULT_FILENAME}{AppConfig.FILE_EXTENSION}{modified} - {AppConfig.APP_NAME}")

    def is_modified(self):
        """Проверка, были ли изменения (упрощенная)"""
        # В реальном приложении нужно отслеживать изменения
        return False

    def save_to_file(self, file_path):
        """Сохранение презентации в файл"""
        try:
            # Создаем временный zip-файл
            temp_zip_path = file_path + ".temp"

            with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Сохраняем слайды
                slides_data = [slide.to_dict() for slide in self.slides]

                # Метаданные
                metadata = {
                    "created": datetime.now().isoformat(),
                    "modified": datetime.now().isoformat(),
                    "format": AppConfig.FORMAT_VERSION,
                    "theme": self.theme.to_dict(),
                    "slides": slides_data
                }

                # Сохраняем метаданные
                zipf.writestr("metadata.json", json.dumps(metadata, indent=2, ensure_ascii=False))

                # Сохраняем изображение фона, если есть
                if self.theme.background_image and os.path.exists(self.theme.background_image):
                    image_ext = os.path.splitext(self.theme.background_image)[1]
                    image_name = "background" + image_ext
                    zipf.write(self.theme.background_image, f"images/{image_name}")

                    # Обновляем путь в теме
                    metadata["theme"]["background_image"] = f"images/{image_name}"
                    zipf.writestr("metadata.json", json.dumps(metadata, indent=2, ensure_ascii=False))

            # Заменяем старый файл новым
            if os.path.exists(file_path):
                os.remove(file_path)
            os.rename(temp_zip_path, file_path)

            self.current_file = file_path
            self.update_window_title()

            # Добавляем документ в историю
            self.recent_docs.add_document(file_path)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить файл: {str(e)}")
            if os.path.exists(temp_zip_path):
                os.remove(temp_zip_path)

    def load_from_file(self, file_path):
        """Загрузка презентации из файла"""
        try:
            with zipfile.ZipFile(file_path, 'r') as zipf:
                # Загружаем метаданные
                metadata_str = zipf.read("metadata.json").decode('utf-8')
                metadata = json.loads(metadata_str)

                # Загружаем тему
                self.theme = PresentationTheme.from_dict(metadata["theme"])

                # Если есть изображение фона, копируем его во временную папку
                if self.theme.background_image and self.theme.background_image.startswith("images/"):
                    image_data = zipf.read(self.theme.background_image)
                    temp_image_path = os.path.join(self.temp_dir, os.path.basename(self.theme.background_image))
                    with open(temp_image_path, 'wb') as f:
                        f.write(image_data)
                    self.theme.background_image = temp_image_path

                # Загружаем слайды
                self.slides = []
                for slide_data in metadata["slides"]:
                    self.slides.append(Slide.from_dict(slide_data))

                self.current_slide_index = 0
                self.current_file = file_path

                self.update_slides_list()
                self.update_window_title()
                self.slide_preview.update()

                # Добавляем документ в историю
                self.recent_docs.add_document(file_path)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл: {str(e)}")

    def closeEvent(self, event):
        """Обработка закрытия окна"""
        if self.maybe_save():
            # Очистка временных файлов
            if os.path.exists(self.temp_dir):
                try:
                    shutil.rmtree(self.temp_dir)
                except:
                    pass
            event.accept()
        else:
            event.ignore()


# ==============================
# ВИДЖЕТ ПРЕДПРОСМОТРА СЛАЙДА
# ==============================
class SlidePreviewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.editor = parent
        self.setMinimumSize(600, 400)

    def paintEvent(self, event):
        """Отрисовка предпросмотра слайда"""
        painter = QPainter(self)

        if not self.editor or not self.editor.slides:
            return

        # Получаем текущий слайд и тему
        if self.editor.current_slide_index >= len(self.editor.slides):
            return

        slide = self.editor.slides[self.editor.current_slide_index]
        theme = self.editor.theme

        # Создаем прямоугольник для слайда (с отступами)
        slide_rect = QRect(20, 20, self.width() - 40, self.height() - 40)

        # Рисуем фон слайда
        if slide.background_image and os.path.exists(slide.background_image):
            # Если у слайда есть свое изображение фона
            pixmap = QPixmap(slide.background_image)
            if not pixmap.isNull():
                painter.drawPixmap(slide_rect, pixmap)
        elif slide.background_color:
            # Если у слайда есть свой цвет фона
            painter.fillRect(slide_rect, QColor(slide.background_color))
        elif theme.background_image and os.path.exists(theme.background_image):
            # Если есть изображение фона в теме
            pixmap = QPixmap(theme.background_image)
            if not pixmap.isNull():
                painter.drawPixmap(slide_rect, pixmap)
        else:
            # Используем цвет фона из темы
            painter.fillRect(slide_rect, QColor(theme.background_color))

        # Рисуем рамку вокруг слайда
        painter.setPen(QColor(200, 200, 200))
        painter.drawRect(slide_rect)

        # Устанавливаем область отсечения для слайда
        painter.save()
        painter.setClipRect(slide_rect)

        # Отображаем содержимое слайда
        self.draw_slide_content(painter, slide, theme, slide_rect)

        painter.restore()

        # Отображаем номер слайда
        painter.setPen(QColor(128, 128, 128))
        painter.setFont(QFont("Noto Sans", 10))
        slide_text = f"Слайд {self.editor.current_slide_index + 1} из {len(self.editor.slides)}"
        painter.drawText(20, self.height() - 5, slide_text)

    def draw_slide_content(self, painter, slide, theme, rect):
        """Отрисовывает содержимое слайда"""
        # Устанавливаем шрифт для заголовка (используем настройки слайда или темы)
        title_font_family = slide.title_font_family or theme.title_font_family
        title_font_size = slide.title_font_size or theme.title_font_size
        title_font_bold = slide.title_font_bold if slide.title_font_bold is not None else theme.title_font_bold

        title_font = QFont(title_font_family, title_font_size * 0.7)  # Уменьшаем для предпросмотра
        title_font.setBold(title_font_bold)

        # Устанавливаем шрифт для текста (используем настройки слайда или темы)
        text_font_family = slide.text_font_family or theme.text_font_family
        text_font_size = slide.text_font_size or theme.text_font_size
        text_font_bold = slide.text_font_bold if slide.text_font_bold is not None else theme.text_font_bold

        text_font = QFont(text_font_family, text_font_size * 0.7)  # Уменьшаем для предпросмотра
        text_font.setBold(text_font_bold)

        # Цвета (используем настройки слайда или темы)
        title_color = slide.title_color or theme.title_color
        text_color = slide.text_color or theme.text_color

        # Внутренние отступы
        padding = 30
        content_rect = rect.adjusted(padding, padding, -padding, -padding)

        # Отображаем в зависимости от типа слайда
        if slide.slide_type == SlideType.TITLE:
            # Титульный слайд
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(content_rect.x(), content_rect.y() + content_rect.height() // 4,
                              content_rect.width(), 60)
            painter.drawText(title_rect, Qt.AlignCenter, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(content_rect.x(), content_rect.y() + content_rect.height() // 2,
                             content_rect.width(), 60)
            painter.drawText(text_rect, Qt.AlignCenter, slide.text)

        elif slide.slide_type == SlideType.TITLE_AND_TEXT:
            # Заголовок и текст
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(content_rect.x(), content_rect.y(), content_rect.width(), 60)
            painter.drawText(title_rect, Qt.AlignLeft, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            text_rect = QRect(content_rect.x(), content_rect.y() + 80, content_rect.width(), content_rect.height() - 80)
            painter.drawText(text_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text)

        elif slide.slide_type == SlideType.TEXT_ONLY:
            # Только текст
            painter.setFont(text_font)
            painter.setPen(QColor(text_color))
            painter.drawText(content_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text)

        elif slide.slide_type == SlideType.TITLE_ONLY:
            # Только заголовок
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            painter.drawText(content_rect, Qt.AlignLeft, slide.title)

        elif slide.slide_type == SlideType.TITLE_AND_TWO_COLUMNS:
            # Заголовок и два блока текста
            painter.setFont(title_font)
            painter.setPen(QColor(title_color))
            title_rect = QRect(content_rect.x(), content_rect.y(), content_rect.width(), 60)
            painter.drawText(title_rect, Qt.AlignLeft, slide.title)

            painter.setFont(text_font)
            painter.setPen(QColor(text_color))

            # Левый блок
            left_rect = QRect(content_rect.x(), content_rect.y() + 80,
                             content_rect.width() // 2 - 10, content_rect.height() - 80)
            painter.drawText(left_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text1)

            # Правый блок
            right_rect = QRect(content_rect.x() + content_rect.width() // 2 + 10, content_rect.y() + 80,
                              content_rect.width() // 2 - 10, content_rect.height() - 80)
            painter.drawText(right_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text2)

        elif slide.slide_type == SlideType.TWO_COLUMNS:
            # Два блока текста
            painter.setFont(text_font)
            painter.setPen(QColor(text_color))

            # Левый блок
            left_rect = QRect(content_rect.x(), content_rect.y(),
                             content_rect.width() // 2 - 10, content_rect.height())
            painter.drawText(left_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text1)

            # Правый блок
            right_rect = QRect(content_rect.x() + content_rect.width() // 2 + 10, content_rect.y(),
                              content_rect.width() // 2 - 10, content_rect.height())
            painter.drawText(right_rect, Qt.AlignLeft | Qt.TextWordWrap, slide.text2)


# ==============================
# ТОЧКА ВХОДА
# ==============================
def main():
    parser = argparse.ArgumentParser(description=AppConfig.APP_NAME)
    parser.add_argument('-f', '--file', type=str, help='Путь к файлу для открытия')
    args = parser.parse_args()

    app = QApplication(sys.argv)

    # Применяем настройки
    settings_manager = SettingsManager()
    settings_manager.apply_theme(app)
    settings_manager.apply_font(app)

    # Устанавливаем иконку приложения
    if os.path.exists(AppConfig.APP_ICON):
        app.setWindowIcon(QIcon(AppConfig.APP_ICON))
    else:
        app.setWindowIcon(QIcon.fromTheme("x-office-presentation"))

    # Создаем и показываем главное окно
    editor = PresentationEditor(file_to_open=args.file)
    editor.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
