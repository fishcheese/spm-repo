#!/bin/bash

# Установка цветов для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция для вывода сообщений об ошибках
error_exit() {
    echo -e "${RED}[ОШИБКА] $1${NC}" >&2
    exit 1
}

# Функция для вывода информационных сообщений
info_msg() {
    echo -e "${GREEN}[ИНФО] $1${NC}"
}

# Функция для вывода предупреждений
warning_msg() {
    echo -e "${YELLOW}[ПРЕДУПРЕЖДЕНИЕ] $1${NC}"
}

# Получаем реальный домашний путь пользователя
# Учитываем случай, когда скрипт запущен с sudo
if [ -n "$SUDO_USER" ]; then
    USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    USER_HOME="$HOME"
fi

# Проверка прав на выполнение скрипта
if [[ $EUID -eq 0 ]]; then
    warning_msg "☠️ скрипт запущен с правами root. Это может быть небезопасно."
    read -p "продолжить? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Определение пути к скрипту
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# 1. Копирование папки eblanoffice/ в домашнюю директорию
info_msg "☝️ копирование папки eblanoffice/ в домашнюю директорию..."
if [[ -d "${SCRIPT_DIR}/eblanoffice" ]]; then
    cp -r "${SCRIPT_DIR}/eblanoffice" "$USER_HOME"/ || error_exit "Не удалось скопировать eblanoffice/"

    # Установка прав доступа
    chmod -R 755 "$USER_HOME"/eblanoffice || warning_msg "Не удалось изменить права доступа для eblanoffice/"
    info_msg "✅✅✅ папка eblanoffice успешно скопирована в $USER_HOME/"
else
    error_exit "☠️☠️☠️ папка eblanoffice/ не найдена в директории скрипта"
fi

# 2. Копирование desktopfiles/ в /usr/share/applications с заменой $HOME
info_msg "☝️копирование файлов .desktop в /usr/share/applications..."
if [[ -d "${SCRIPT_DIR}/desktopfiles" ]]; then
    # Проверка существования директории
    if [[ ! -d "/usr/share/applications" ]]; then
        error_exit "❌❌❌ чёзабретта - директория /usr/share/applications не существует"
    fi

    # Обработка каждого .desktop файла
    for desktop_file in "${SCRIPT_DIR}/desktopfiles/"*.desktop; do
        if [[ -f "$desktop_file" ]]; then
            # Получаем имя файла
            filename=$(basename "$desktop_file")

            # Создаем временный файл с заменой $HOME на реальный путь
            temp_file="/tmp/${filename}.tmp"

            # Заменяем $HOME на реальный путь пользователя
            # Используем двойные кавычки для корректной обработки путей с пробелами
            sed "s|\$HOME|$USER_HOME|g" "$desktop_file" > "$temp_file"

            # Проверяем успешность замены
            if grep -q "\$HOME" "$temp_file"; then
                warning_msg "☠️ в файле $filename остались необработанные переменные \$HOME"
            fi

            # Копируем обработанный файл
            if [[ ! -w "/usr/share/applications" ]]; then
                info_msg "копирование $filename с использованием sudo..."
                sudo cp "$temp_file" "/usr/share/applications/${filename}" 2>/dev/null || warning_msg "☠️ не удалось скопировать $filename"
            else
                cp "$temp_file" "/usr/share/applications/${filename}" || warning_msg "☠️ не удалось скопировать $filename"
            fi

            # Удаляем временный файл
            rm -f "$temp_file"

            info_msg "✅✅✅ файл $filename обработан и скопирован"
        fi
    done
    info_msg "✅✅✅ desktop файлы успешно обработаны и скопированы"

    # Дополнительно: проверяем наличие $HOME в скопированных файлах
    info_msg "✅✅✅ проверка замены \$HOME в скопированных файлах..."
    for desktop_file in /usr/share/applications/*.desktop; do
        if [[ -f "$desktop_file" ]] && grep -q "\$HOME" "$desktop_file"; then
            warning_msg "в файле $(basename "$desktop_file") обнаружен необработанный \$HOME"
        fi
    done

else
    warning_msg "папка desktopfiles/ не найдена, пропускаем копирование .desktop файлов"
fi

# 3. Установка PySide6
info_msg "☝️проверка наличия PySide6..."

# Функция для проверки установки PySide6
check_pyside6() {
    python3 -c "import PySide6" 2>/dev/null
    return $?
}

# Функция для установки через pip
install_via_pip() {
    info_msg "☝️попытка установки PySide6 через pip..."

    # Проверка наличия pip
    if ! command -v pip3 &> /dev/null; then
        warning_msg "pip3 не найден, попытка установки pip..."

        # Определение дистрибутива и установка pip
        if command -v apt &> /dev/null; then
            sudo apt update && sudo apt install -y python3-pip || return 1
        elif command -v dnf &> /dev/null; then
            sudo dnf install -y python3-pip || return 1
        elif command -v yum &> /dev/null; then
            sudo yum install -y python3-pip || return 1
        elif command -v pacman &> /dev/null; then
            sudo pacman -Sy --noconfirm python-pip || return 1
        elif command -v zypper &> /dev/null; then
            sudo zypper install -y python3-pip || return 1
        else
            warning_msg "❌❌❌ не удалось определить пакетный менеджер для установки pip"
            return 1
        fi
    fi

    # Попытка установки через pip
    pip3 install PySide6 --user 2>/dev/null

    # Проверка успешности установки
    if check_pyside6; then
        info_msg "✅✅✅ pyside6 успешно установлен через pip (--user)"
        return 0
    fi

    # Если установка с --user не сработала, пробуем без --user (может потребовать sudo)
    warning_msg "☠️☠️☠️ установка с --user не удалась, пробуем глобальную установку..."
    sudo pip3 install PySide6 2>/dev/null

    if check_pyside6; then
        info_msg "✅✅✅ pySide6 успешно установлен через pip (глобально)"
        return 0
    fi

    return 1
}

# Функция для определения и использования пакетного менеджера
install_via_package_manager() {
    info_msg "попытка установки через пакетник..."

    if command -v apt &> /dev/null; then
        info_msg "☝️обнаружен apt (🤙Lesbian/Ubuntu)"
        sudo apt update && sudo apt install -y python3-pyside6 2>/dev/null || \
        sudo apt install -y pyside6 2>/dev/null || \
        sudo apt install -y python3-pyside6.qtcore python3-pyside6.qtgui python3-pyside6.qtwidgets 2>/dev/null
        return $?

    elif command -v dnf &> /dev/null; then
        info_msg "☝️обнаружен dnf (Fedora/RHEL)"
        sudo dnf install -y python3-pyside6 2>/dev/null || \
        sudo dnf install -y pyside6 2>/dev/null
        return $?

    elif command -v yum &> /dev/null; then
        info_msg "☝️обнаружен yum (CentOS/RHEL)"
        sudo yum install -y python3-pyside6 2>/dev/null || \
        sudo yum install -y pyside6 2>/dev/null
        return $?

    elif command -v pacman &> /dev/null; then
        info_msg "☝️обнаружен pacman (🤙arch btw)"
        sudo pacman -Sy --noconfirm pyside6 2>/dev/null || \
        sudo pacman -Sy --noconfirm python-pyside6 2>/dev/null
        return $?

    elif command -v zypper &> /dev/null; then
        info_msg "☝️обнаружен zypper (openSUSE)"
        sudo zypper install -y python3-pyside6 2>/dev/null || \
        sudo zypper install -y pyside6 2>/dev/null
        return $?

    else
        warning_msg "☠️☠️☠️ не удалось определить пакетный менеджер. бро, что за ноунейм дистр ты юзаешь?"
        return 1
    fi
}

# Основная логика установки PySide6
if check_pyside6; then
    info_msg "✅✅✅ pyside уже установлен"
else
    # Сначала пробуем установить через pip
    if ! install_via_pip; then
        warning_msg "❌❌❌ установка через pip не удалась"

        # Проверяем, была ли ошибка externally-managed-environment
        pip_error=$(pip3 install PySide6 2>&1 | grep -i "externally-managed-environment")

        if [[ -n "$pip_error" ]] || [[ $? -ne 0 ]]; then
            info_msg "❌❌❌ ошибка externally-managed-environment, пробуем через пакетник"

            # Пробуем установить через пакетный менеджер
            if install_via_package_manager; then
                if check_pyside6; then
                    info_msg "✅✅✅ pyside6 успешно установлен через пакетный менеджер"
                else
                    warning_msg "☠️☠️☠️ пакетник сообщил об успехе, но pyside6 не импортируется"
                fi
            else
                error_exit "❌❌❌ чёзабретта - не удалось установить pyside6 ни через pip, ни через пакетный менеджер"
            fi
        else
            error_exit "❌❌❌ не удалось установить pyside6 через pip"
        fi
    fi
fi

# Финальная проверка
info_msg "☝️проверка установки pyside6..."
if check_pyside6; then
    info_msg "✅✅✅ pyside успешно установлен и работает"
else
    warning_msg "☠️☠️☠️ pyside не проходит проверку импорта. Возможно, требуется перезапуск терминала или перелогин."
fi

info_msg "🤙установка eblanoffice завершена успешно!"
notify-send "🤙установка eblanoffice завершена успешно! ✅✅✅" -a "установщик eblanoffice" --icon ~/eblanoffice/icons/office.png -h string:sound-name:outcome-success
