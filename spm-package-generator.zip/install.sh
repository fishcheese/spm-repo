#!/bin/bash

# Установщик для spm-package-generator
# Автоматический перезапуск с правами суперпользователя
if [ "$EUID" -ne 0 ]; then
    echo "Требуются права суперпользователя. Перезапуск с sudo..."

    # Проверяем наличие sudo
    if command -v sudo >/dev/null 2>&1; then
        exec sudo "$0" "$@"
    else
        # Если sudo нет, пробуем через su
        echo "sudo не найден. Попытка через su..."
        exec su -c ""$0" $@"
    fi
    exit 1
fi

# Проверка системных зависимостей
echo "Проверка системных зависимостей..."

# Проверка python3
if ! command -v python3 &> /dev/null; then
    echo "Предупреждение: Отсутствует системная зависимость 'python3'"
    echo "Установите её командой: apt install python3"
    read -p "Установить сейчас? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        apt install -y python3 || echo "Не удалось установить python3. Продолжение установки..."
    fi
fi

# Проверка Python зависимостей
echo "Проверка Python зависимостей..."

# Проверка Python модуля PySide6
if ! python3 -c "import PySide6" &> /dev/null; then
    echo "Предупреждение: Отсутствует Python модуль 'PySide6'"
    read -p "Установить через pip? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        pip install PySide6 || echo "Не удалось установить PySide6. Продолжение установки..."
    fi
fi

echo "Установка spm-package-generator..."
cp ./spm-package-generator /usr/bin/
chmod +x /usr/bin/spm-package-generator

# Копирование desktop файла
echo "Добавление ярлыка в меню приложений..."
cp ./spm-package-generator.desktop /usr/share/applications/

# Копирование иконки
echo "Установка иконки..."
cp ./spm-package-generator.png /usr/share/pixmaps/

echo "Установка завершена успешно!"
echo "Программа установлена в /usr/bin/"
