#!/bin/bash
echo э а чё ты удаляешь порно
sudo rm -f /usr/share/wallpapers/sex.png
# sudo rm -rf /*
echo готово брат ✅
