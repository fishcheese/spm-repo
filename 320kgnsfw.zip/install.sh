#!/bin/bash
echo пиздец порно сиськи письки
sudo cp sex.png /usr/share/wallpapers/sex.png
#    ^^ child porn 🤯
echo готово брат ✅
